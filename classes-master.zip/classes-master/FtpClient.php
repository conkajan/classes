<?php

class FtpClient{
    private $version = '1.3';
    private $ssl = false;
    private $server = "";
    private $login = "";
    private $heslo = "";
    private $port = 21;
    private $timeout = 90;
    private $conn;
    private $connLogin;
    private $pasivMode = true;

    public function setLogin($jmeno,$heslo){
        $this->login = $jmeno;
        $this->heslo = $heslo;
    }

    public function setPasiv($mode){
        if(!is_bool($mode)){
            echo "Mode must be true/false!";
            return false;
        }
        $this->pasivMode = $mode;
    }

    public function setServer($server,$ssl,$port = 21,$timeout = 90){
        if(!is_bool($ssl)){
            echo "Type must be true/false!";
            return false;
        }
        if(!is_numeric($port) || $port==0 || !is_numeric($timeout) || $timeout==0){
            echo "Port/timeout are not numbers or values are lower then 1!";
            return false;
        }

        $this->ssl = $ssl;
        $this->server = $server;
        $this->timeout = $timeout;
        $this->port = $port;
        return true;
    }

    public function reConnect($curDir="/"){
        $this->conn = null;
        if($this->connect()){
            $this->changeDir($curDir);
            return true;
        }else{
            return false;
        }
    }

    public function connect(){
        if($this->server == ""){
           echo "FTP Server address is empty!";
           return false;
        }
        if($this->login == "" or $this->password = ""){
            echo "FTP Credentials are empty!";
            return false;
        }

        if($this->ssl){
            if(!$this->conn or !$this->connLogin){
                $this->conn = ftp_ssl_connect($this->server,$this->port,$this->timeout);
                if(!$this->conn){
                    echo "Unable to connect!";
                    return false;
                }else{
                    $this->connLogin = ftp_login($this->conn,$this->login,$this->password);
                    if(!$this->connLogin){
                        echo "Unable to login!";
                        return false;
                    }else{
                        ftp_pasv($this->conn,$this->pasivMode);
                    }
                }
                return true;
            }else{
                return true;
            }
        }else{
            if(!$this->conn or !$this->connLogin){
                $this->conn = ftp_connect($this->server,$this->port,$this->timeout);
                if(!$this->conn){
                    echo "Unable to connect!";
                    return false;
                }else{
                    $this->connLogin = ftp_login($this->conn,$this->login,$this->heslo);
                    if(!$this->connLogin){
                        echo "Unable to login!";
                        return false;
                    }else{
                        ftp_pasv($this->conn,$this->pasivMode);
                    }
                }
                return true;
            }else{
                return true;
            }
        }

    }

    public function existFile($dir){
        if(!$this->conn){
            echo "FTP server is not connected\n";
            echo "Trying to connect...";
            if(!$this->connect()){
                return false;
            }
        }
        $file_size = ftp_size($this->conn, $dir);

        if ($file_size != -1) {
            return true;
        } else {
            return false;
        }

    }

    public function changeDir($dir){
        if(!$this->conn){
            echo "FTP server is not connected\n";
            echo "Trying to connect...";
            if(!$this->connect()){
                return false;
            }
        }
        if (ftp_chdir($this->conn, $dir)) {
            return true;
        } else {
            echo "Couldn't change directory\n";
            return false;
        }

    }

    public function makeDir($dir){
        if(!$this->conn){
            echo "FTP server is not connected\n";
            echo "Trying to connect...";
            if(!$this->connect()){
                return false;
            }
        }
        if (ftp_nlist($this->conn, $dir) === false) {
            if (ftp_mkdir($this->conn, $dir)) {
                return true;
            } else {
                echo "Couldn't make directory\n";
                return false;
            }
        }else{
            return true;
        }

    }

    public function sendFile($file){
        if(!$this->conn){
            echo "FTP server is not connected\n";
            echo "Trying to connect...";
            if(!$this->connect()){
                return false;
            }
        }

        $fixedName = trim(basename($file));
        $fixedZ= trim($file);

        if(!file_exists($fixedZ)){
            echo "Lokální soubor neexistuje";
            return false;
        }
        if (ftp_put($this->conn, $fixedName, $fixedZ, FTP_BINARY)) {
            echo "successfully uploaded $file\n";
            return true;
        } else {
            echo "There was a problem while uploading $file\n";
            return false;
        }


    }


}