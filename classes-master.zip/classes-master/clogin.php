<?php
require_once('/var/www/interface/lib/class/DB.php');
class clogin
{
    private $version = '1.1';
    protected $db;
    public $dbtype = "pg";
    public $dlogin = "dlogin";
    public $login = "login";
    public $password = "password";
    public $_login = "login";
    public $_lang = "lang";
    public $connect;
    public $ip;
    public $nmd5 = 1;
    public $ntime = 3600;
    public $fntime = "ntime";
    public $cwhere = " ";
    public $use_ip = 0;
    public $avars;

    public $doch_dbserver = '10.0.0.57';
    public $doch_dbport = '5432';
    public $doch_db = 'recordings';


    public $log_dbserver = '10.0.0.57';
    public $log_user = 'log';
    public $log_db = 'databaze';
    public $log_schema = 'log';
    public $log_dbport = '5433';
    public $log_table = 'history';
    public $log_script_name = "";
    public $log_connect = "";
    public $log_id = "";
    public $ar_proxy = array("10.0.0.252", "10.0.0.240", "127.0.0.1", "192.168.100.2");
    public $table1 = "doch_t_users2_logins";

    public function version()
    {
        return $this->version;
    }
    public function log_init()
    {
        if (class_exists('db')) {
            $this->db = new db();
            $this->db->server_type = 'PG';
            $this->db->server_address = $this->log_dbserver;
            $this->db->server_port = $this->log_dbport;
            $this->db->server_database = $this->log_db;
        } else {
            die("Pro funk�nost je t�eba pou��t t��du DB.");
        }
        $this->nuser=$this->user_id(); //Vyu�it� v dochin� !!
    }
    public function doch_init()
    {
        if (class_exists('db')) {
            $this->db = new db();
            $this->db->server_type = 'PG';
            $this->db->server_address = $this->doch_dbserver;
            $this->db->server_port = $this->doch_dbport;
            $this->db->server_database = $this->doch_db;
        } else {
            die("Pro funk�nost je t�eba pou��t t��du DB.");
        }
    }
    public function txtloging($toto_zapsat)
    {
        //$fajlik = fopen("/var/www/dev/log_login.txt","a");
        //echo chr(13).$toto_zapsat.chr(13);
        //$ted = getdate();
        //fwrite($fajlik,$ted["mday"].".".$ted["mon"].".".$ted["year"]." ".$ted["hours"].":".$ted["minutes"].":".$ted["seconds"]."\t".$toto_zapsat.chr(13));

        //fclose($fajlik);
    }
    public function log_start($cq="") {
        //VYU�IT� V DOCHIN�
        $this->log_init();
        $ctable=$this->log_schema.".".$this->log_table;
        $ctable_seq=$ctable."_id_seq";
        $cq=addslashes($cq);
        $ci="insert into $ctable (user_id,query,t_start,script_name) values (?,?,now(),?);"; //select last_value from $ctable_seq
        $ci1="select last_value from $ctable_seq";
        $this->db->query_bind($ci,array($this->nuser,$cq,$this->log_script_name),array(PDO::PARAM_INT,PDO::PARAM_STR,PDO::PARAM_STR));

        if ($v_log=$this->db->query($ci1)):
            $this->log_id=$v_log[0]['last_value'];
        endif;
        return $this->log_id;
    }
    public function log_end($cerr="OK",$nn=0) {
        $ctable=$this->log_schema.".".$this->log_table;
        $this->log_id=$this->log_id * 1;
        $nn= ($nn==0) ? $this->log_id : $nn;

        $cu="update $ctable set error=e'$cerr',t_stop=now() where id = $nn";

        if (!$this->db->query($cu)):
            echo "Chyba logu";
            die;
        endif;
    }
    public function remot()
    {
        //global $_COOKIE,$_POST;
        $cforw = "";
        $cforwfor = "";
        $cforwfor2 = "";
        $chttp_via = "";
        $remoteaddr = "";

        $this->txtloging("\n\nPoustim fce remot()");
        //print_r($_COOKIE);

        if (isset($_POST["login_user"])):
            $this->txtloging("remot -> je zadan login_user" . $_POST["login_user"]);
            $add1 = $_POST["login_user"];
            setcookie("cipad", $add1, time() + 3600 * 10, "/","comdataczech.cz",0);
            $this->txtloging("remot1 -> add cookie " . $add1);
        else:
            $kubafix = explode("_", $_COOKIE["cipad"]);
            $fixed_kukie = array_unique($kubafix);
            $fixed_kukie = implode("_", $fixed_kukie);
            $this->txtloging("remot_jen beru -> add cookie " . $_COOKIE["cipad"]);
            $add1 = $fixed_kukie;
            $this->txtloging("remot_opravene kukie -> cookie " . $fixed_kukie);
        endif;

        if (isset($_POST["sms_kod"])):
            $this->txtloging("remot -> isset postik smskod " . $_POST["sms_kod"]);
            $add1 = $add1 . "_" . $_POST["sms_kod"];
            setcookie("cipad", "$add1", time() + 3600 * 10, "/","comdataczech.cz",0);
            setcookie("cipad1", "$add1", time() + 3600 * 10, "/","comdataczech.cz",0);
            $this->txtloging("remot2 -> set cookie " . $add1);
        endif;

        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])):
            $cforwfor = $_SERVER["HTTP_X_FORWARDED_FOR"];
        endif;

        if (isset($_SERVER["HTTP_X_FORWARDED"])):
            $cforwfor2 = $_SERVER["HTTP_X_FORWARDED"];

        endif;

        if (isset($_SERVER["HTTP_FORWARDED"])):
            $cforw = $_SERVER["HTTP_FORWARDED"];

        endif;

        $remoteaddr = $_SERVER["REMOTE_ADDR"];
        if (isset($_SERVER['HTTP_VIA'])):
            $chttp_via = $_SERVER['HTTP_VIA'];
        endif;
        $remotx = $remoteaddr . $cforwfor . $cforwfor2 . $chttp_via;
        $this->txtloging("remot -> remoteX " . $remotx);

        return $remotx . "_" . $add1;
    }
    public function nmd5($ctxt, $cn = 1)
    {
        for ($i = 1; $i <= $cn; $i++) :
            $ctxt = md5($ctxt);
        endfor;
        return $ctxt;
    }


    // -- overuje -- vola se vzdy ---
    public function login()
    {
        $this->txtloging(" 1 Poustim fce login()");
        global $_POST, $_COOKIE;

        $_over2 = 0;
        foreach ($_POST as $ckpost => $cpvalue) {
            $$ckpost = $cpvalue;
        }

        if (isset($this->table1)) $this->table = $this->table1;

        if (!isset($login_password)) $login_password = "xxxxx";
        $login_password_sha2 = hash('sha512', $login_password);
        $login_password = $this->nmd5($login_password, $this->nmd5);

        if ($this->dbtype == "ms"):
            $this->table1 = $this->dbname . ".dbo." . $this->table;
        else:
            $this->table1 = $this->table;
        endif;

        if (isset($login_hidden) && $login_hidden * 1 == 1):
            $this->txtloging("2login -> login_hidden 1");

            $dotaz_update_p = array($login_user, $this->ip, $login_user);
            $dotaz_update_pt = array(PDO::PARAM_STR, PDO::PARAM_INT, PDO::PARAM_STR);
            $dotaz_update = "update $this->table1 set $this->dip = ? where $this->dip = ? and $this->_login::text <> ?";

            $dotaz1 = "Select *,90-(now()::date-p_change::date) as p_change2,user_smlouva_plat(now()::date,uzivateleid) as smlouva from $this->table1 where $this->_login=? and case when sha2 is not null then sha2=? else $this->password=? end $this->cwhere order by dlogin desc limit 1";
            $d1_p = array($login_user, $login_password_sha2, $login_password);
            $d1_tp = array(PDO::PARAM_STR, PDO::PARAM_STR, PDO::PARAM_STR);

            $this->txtloging("3login -> dotaz " . $dotaz_update . $dotaz1);
        else:
            $d1_p = array($this->ip);
            $d1_tp = array(PDO::PARAM_STR);
            $dotaz1 = "Select *,90-(now()::date-p_change::date) as p_change2,user_smlouva_plat(now()::date,uzivateleid) as smlouva from $this->table1 where $this->dip=? $this->cwhere order by $this->dlogin desc  limit 1";

            $this->txtloging("4-predlogin -> dotaz " . $dotaz1); //TODO: do dotazu dosadit array() s daty
            $predvoj = explode("'", $dotaz1);
            $kubafixq = explode("_", $predvoj[0]);
            $fixed_q = array_unique($kubafixq);
            $fixed_q = implode("_", $fixed_q);
            $predvoj[1] = $fixed_q;
            $q = implode("'", $predvoj);
            $this->txtloging("4login -> dotaz " . $q);
        endif;

        $ntmp = $this->ntime * -2;  //odpocet pro odhlaseni talcitkem
        switch ($this->dbtype):
            case "ms":
                $var_now = "convert(varchar,getdate(),121)";
                $q = $this->pg2msq($q, $this->fntime);
                $var_add = "convert(varchar,dateadd(ss,$this->ntime,$this->dlogin),121)";

                $var_minus = "dateadd(ss,$ntmp,$this->dlogin)";  //odpocet pro odhlaseni talcitkem
                break;
            case "pg":
                $var_now = "now()";
                $var_add = " $this->dlogin + ' $this->ntime '";
                $var_minus = " $this->dlogin + ' $ntmp seconds '";
                break;
        endswitch;

        $this->doch_init();

        if (isset($dotaz_update)) {
            $this->db->query_bind($dotaz_update, $dotaz_update_p, $dotaz_update_pt);
            $v = $this->db->query_bind($dotaz1, $d1_p, $d1_tp)[0];
        } else {
            $v = $this->db->query_bind($dotaz1, $d1_p, $d1_tp)[0];
        }
        $this->txtloging("4realylogin -> dotaz " . $dotaz1);


        if (!$arv = $v):

            $this->txtloging("5login -> bad login login_user ($login_user , $login_lang)");
            $this->login_user($login_user, $login_lang, 'bad');

        else:

            if ($arv[0][27] == 1) {
                $fix_pocet_pokusu = $this->db->query_bind("update doch_t_users2_logins set p_rozhrani = 1 where login = ?", array($login_user), array(PDO::PARAM_STR));
                $this->login_user($login_user, $login_lang, 'blok');
            }

            $_SESSION['ng_user_id'] = intval($arv[0], 10);
            //-----ZDE ZACINA PROCES PO USPESNEM PRIHLASENI JMENO HESLO.
            if (isset($login_user)) {
                $this->txtloging("6login -> uspesny login " . $login_user);
                $this->db->query_bind("update doch_t_users2_logins set p_rozhrani = 1 where login = ?", array($login_user), array(PDO::PARAM_STR));
            }
            if (isset($this->vars)):
                $avars = explode(",", $this->vars);
                foreach ($avars as $ck_value) {
                    $varname = "this->$ck_value";
                    $ctmp = $v[$ck_value];
                    $this->avars["$ck_value"] = $ctmp;
                }
            endif;

            if (isset($login_hidden) && $login_hidden == 1):
                $this->txtloging("7login -> login_hidden 1 ");
                if (isset($this->_lang) && !empty($login_lang)) {
                    $dotaz_v1 = "update $this->table1 set $this->fntime=?,$this->dlogin=?,$this->dip=?,$this->_lang = ? where $this->_login=?  returning *";
                    $v1 = $this->db->query_bind($dotaz_v1, array($this->ntime, $var_now, $this->ip, $login_lang, $login_user), array(PDO::PARAM_INT, PDO::PARAM_INT, PDO::PARAM_STR, PDO::PARAM_STR, PDO::PARAM_STR))[0];
                } else {
                    $dotaz_v1 = "update $this->table1 set $this->fntime=?,$this->dlogin=?,$this->dip=? where $this->_login=?  returning *";
                    $v1 = $this->db->query_bind($dotaz_v1, array($this->ntime, $var_now, $this->ip, $login_user), array(PDO::PARAM_INT, PDO::PARAM_INT, PDO::PARAM_STR, PDO::PARAM_STR))[0];
                }
                $this->txtloging("8login -> dotaz " . $dotaz_v1);
                if(isset($_COOKIE["cipad1"])) {
                    $alast = explode("_", $_COOKIE["cipad1"]);
                }


                if ($v1["sms"] == 1 && $v1["sms_kod"] == 0):
                    $_over2 = 1;
                    $this->txtloging("9login -> sms_kod 0 ");
                endif;
                if ($v1["sms"] == 1 && !in_array($v1["sms_kod"], $alast)):
                    $this->txtloging("9.1login -> chci_sms ");
                    $_over2 = 1;
                endif;
            else:
                $this->txtloging("11login -> login_hiden != 1 ");
                if(isset($this->_lang) && !empty($this->_lang)){
                    $dotaz_q = "Select $this->_login as login,$this->id as id,$var_add as cur_date,$var_now as akt_cas, $this->_lang as lang from $this->table1 where $this->dip=? order by $this->dlogin desc limit 1";
                    $addlang = "ok";
                }else {
                    $dotaz_q = "Select $this->_login as login,$this->id as id,$var_add as cur_date,$var_now as akt_cas from $this->table1 where $this->dip=? order by $this->dlogin desc limit 1";
                }
                $this->txtloging("12login -> dotaz " . $dotaz_q);


                switch ($this->dbtype):
                    case "ms":
                        $var_now = "convert(varchar,getdate(),121)";
                        $q = $this->pg2msq($q, $this->fntime);
                        $var_add = "convert(varchar,dateadd(ss,$this->ntime,$this->dlogin),121)";
                        break;
                    case "pg":
                        $var_now = "now()";
                        $var_add = " $this->dlogin + ' $this->ntime '";
                        break;
                endswitch;

                if(isset($addlang) and $addlang = "ok"){
                    $v = $this->db->query_bind($dotaz_q,array($this->ip),array(PDO::PARAM_STR));
                }else{
                    $v = $this->db->query_bind($dotaz_q,array($this->ip),array(PDO::PARAM_STR));
                }

                $t1 = $v[0]['cur_date'];
                $t2 = $v[0]['akt_cas'];
                $l1 = $v[0]['login'];
                $lang1 = $v[0]['lang'];
                $id = $v[0]['id'];


                if ($t1 >= $t2 and $t1 != ''):
                    //oprava kuba 201804
                    $oprava = explode("_", $this->ip);
                    $finalka = array();
                    $predchozi = '';
                    foreach ($oprava as $oprava2) {
                        if ($predchozi != $oprava2) {
                            $finalka[] = $oprava2;
                            $predchozi = $oprava2;
                        }
                    }
                    $this->ip = implode("_", $finalka);
                    if(isset($this->_lang) && !empty($login_lang)) {
                        echo "X";
                        $dotaz1_q1 = "update $this->table1 set $this->fntime=?,$this->dlogin=$var_now,$this->dip=?,$this->_lang = ?  where $this->id=? and now() - $this->dlogin > '10 minutes'::interval ;";
                        $lang_q = "ok";
                    }else {
                        $dotaz1_q1 = "update $this->table1 set $this->fntime=?,$this->dlogin=$var_now,$this->dip=?  where $this->id=? and now() - $this->dlogin > '10 minutes'::interval ;";
                    }


                    $this->txtloging("13login -> dotaz " . $dotaz1_q1);
                    if(isset($lang_q) and $lang_q == "ok"){ //$login_lang
                        echo "X1";
                        $v = $this->db->query_bind($dotaz1_q1,array($this->ntime,$this->ip,$login_lang,$id),array(PDO::PARAM_INT,PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_INT));
                    }else {
                        $v = $this->db->query_bind($dotaz1_q1,array($this->ntime,$this->ip,$id),array(PDO::PARAM_INT,PDO::PARAM_STR,PDO::PARAM_INT));
                    }

                    if (!$v) {
                    } else {
                        $alast = explode("_", $_COOKIE["cipad1"]);
                        if ($v[0]["sms"] == 1 && $v[0]["sms_kod"] == 0):
                            $_over2 = 1;
                        endif;
                        if ($v[0]["sms"] == 1 && !in_array($v[0]["sms_kod"], $alast)):
                        endif;
                    }
                else:
                    $this->txtloging("14login -> odhlaseni ");
                endif;
                //logout odhl�en�
                if (isset($login_hidden) && $login_hidden * 1 == 2):
                    $this->txtloging("15login -> login hidden = 2 ");
                    $id = $this->user_id();

                    $q_o2 = "update $this->table1 set sms_kod=0 where $this->id = ? RETURNING *";
                    $this->txtloging("16login -> dotaz " . $q_o2);
                    $v_o2 = $this->db->query_bind($q_o2,array($id),array(PDO::PARAM_INT));

                    if(isset($this->_lang) && !empty($login_lang)) {
                        $q1 = "update $this->table1 set $this->fntime=?,$this->dlogin=$var_minus,$this->dip=?,$this->_lang = ? where $this->id=?";
                        $lang_q1 = "ok";
                    }else {
                        $q1 = "update $this->table1 set $this->fntime=?,$this->dlogin=$var_minus,$this->dip=? where $this->id=?";
                    }

                    $q1 = str_replace(",lang as lang", "", $q1);
                    $this->txtloging("17login -> dotaz " . $q1);
                    if(isset($lang_q1) and $lang_q1 == "ok"){
                        $v = $this->db->query_bind($q1,array($this->ntime,$this->ip,$login_lang,$id),array(PDO::PARAM_INT,PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_INT));
                    }else {
                        $v = $this->db->query_bind($q1,array($this->ntime,$this->ip,$id),array(PDO::PARAM_INT,PDO::PARAM_STR,PDO::PARAM_INT));
                    }

                    $past = time() - 3600;
                    foreach ($_COOKIE as $key => $value) {
                        setcookie($key, $value, $past, '/',"comdataczech.cz",0);
                    }

                    unset($_SESSION['ng_user_id']);
                    $_COOKIE["cipad"] = '';

                    $this->txtloging("18login -> login_user ");
                    $this->login_user($l1, $lang1);
                endif;

            endif;
            if ($_over2 == 1):
                $this->txtloging("19login -> over2 = 1 ");
                if (!isset($id)):
                    $cwhere = " $this->login = '$login_user' ";  //TODO: bind
                else:
                    $cwhere = " $this->id = $id "; //TODO: bind
                endif;
                $q_o2 = "update $this->table1 set sms_kod=substr(random()::text,3,4)::int where $cwhere returning *"; //TODO: bind
                $this->txtloging("20login -> dotaz " . $q_o2);
                $v_o2 = $this->db_query($this->connect, $q_o2, $this->dbtype);
                while ($a_o2 = pg_fetch_assoc($v_o2)):
                    $sms_kod = $a_o2["sms_kod"];
                endwhile;
                $this->user_sms($sms_kod);

                $q1 = "update $this->table1 set $this->fntime=$this->ntime,$this->dlogin=$var_now,$this->dip='$this->ip'||'_$sms_kod' where $this->_login='$login_user'  returning *"; //TODO: bind
                $ve2 = $this->db_query($this->connect, $q1, $this->dbtype);
                $this->txtloging("20.1login -> dotaz " . $q1);

                $this->txtloging("21login -> user_sms (" . $sms_kod . ")");


                die;
                $q_o2 = "update $this->table1 set sms_kod=0 where $this->id = $id returning *"; //TODO: bind
                $this->txtloging("22login -> dotaz " . $q_o2);
                $v_o2 = $this->db_query($this->connect, $q_o2, $this->dbtype);


                echo "<br>$sms_kod<br>";

                ?>

            <?php

            endif;
            //die;
        endif;
        if (isset($login_hidden) && $login_hidden == 3):

            $this->txtloging("23login -> login_hidden = 3 ");
            $id = $this->user_id();

            $q = "select sms_kod from $this->table1 where $this->id = $id and sms_kod = $sms_kod"; //TODO: bind
            $this->txtloging("24login -> dotaz $q ");
            $v = $this->db_query($this->connect, $q, $this->dbtype);
            if (!$a_ok = pg_fetch_assoc($v)):
                $q_o2 = "update $this->table1 set sms_kod=0 where $this->id = $id returning *"; //TODO: bind
                $v_o2 = $this->db_query($this->connect, $q_o2, $this->dbtype);
                $this->txtloging("25login -> dotaz $q_o2 ");
            endif;


        endif;
    }




    public function posli_sms($data, $login, $password)
    {
        $url = 'http://10.0.0.100/new.php';
        $port = 1234;
        $referer = '';
        // Convert the data array into URL Parameters like a=b&foo=bar etc.
        $data = http_build_query($data);
        //echo $data;
        // parse the given URL
        $url = parse_url($url);

        if ($url['scheme'] != 'http') {
            die('Error: Only HTTP request are supported !');
        }

        // extract host and path:
        $host = $url['host'];
        $path = $url['path'];

        // open a socket connection on port 80 - timeout: 30 sec
        $fp = fsockopen($host, $port, $errno, $errstr, 30);

        if ($fp) {

            // send the request headers:
            fputs($fp, "POST $path HTTP/1.1\r\n");
            fputs($fp, "Host: $host\r\n");
            fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
            fputs($fp, "Content-length: " . strlen($data) . "\r\n");
            fputs($fp, "Authorization: basic " . base64_encode($login . ":" . $password) . "\r\n\r\n");
            //fpassthru($fp);
            fputs($fp, $data);
            fputs($fp, "Connection: close\r\n\r\n");


            $result = '';
            while (!feof($fp)) {
                // receive the results of the request
                $result .= fgets($fp, 128);
            }
        } else {
            return array(
                'status' => 'err',
                'error' => "$errstr ($errno)"
            );
        }

        // close the socket connection:
        fclose($fp);

        // split the result header from the content
        $result = explode("\r\n\r\n", $result, 2);
        //$result2 = $result;
        $header = isset($result[0]) ? $result[0] : '';
        //$content = isset($result[1]) ? $result[1] : '';
        $content = $result;
        // return as structured array:
        return array(
            'status' => 'ok',
            'header' => $header,
            'content' => $content
        );
    }
    function over_sms($data, $login, $password) {
        $url = 'http://10.0.0.100/new.php';
        $port = 1234;
        $referer='';
        // Convert the data array into URL Parameters like a=b&foo=bar etc.
        $data = http_build_query($data);
        //echo $data;
        // parse the given URL
        $url = parse_url($url);

        if ($url['scheme'] != 'http') {
            die('Error: Only HTTP request are supported !');
        }

        // extract host and path:
        $host = $url['host'];
        $path = $url['path'];

        // open a socket connection on port 80 - timeout: 30 sec
        $fp = fsockopen($host, $port, $errno, $errstr, 30);

        if ($fp){

            // send the request headers:
            fputs($fp, "POST $path HTTP/1.1\r\n");
            fputs($fp, "Host: $host\r\n");
            fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
            fputs($fp, "Content-length: ". strlen($data) ."\r\n");
            fputs($fp, "Authorization: basic ".base64_encode($login.":".$password)."\r\n\r\n");
            //fpassthru($fp);
            fputs($fp, $data);
            fputs($fp, "Connection: close\r\n\r\n");


            $result = '';
            while(!feof($fp)) {
                // receive the results of the request
                $result .= fgets($fp, 128);
            }
        }
        else {
            return array(
                'status' => 'err',
                'error' => "$errstr ($errno)"
            );
        }

        // close the socket connection:
        fclose($fp);

        // split the result header from the content
        $result = explode("\r\n\r\n", $result, 2);
        //$result2 = $result;
        $header = isset($result[0]) ? $result[0] : '';
        //$content = isset($result[1]) ? $result[1] : '';
        $content = $result;
        // return as structured array:
        return array(
            'status' => 'ok',
            'header' => $header,
            'content' => $content
        );
    }
    public function odesli_sms($kam, $text, $ide, $popis, $predvolba, $email, $respo)
    {
        //include("login.php");
        $post_data = array('komu' => $kam, 'text' => $text, 'predvolba' => $predvolba);
        //$this->posli_sms($post_data,'o2sms','outuesemes');
        ob_start();
        //
        $this->posli_sms($post_data, 'o2sms', 'outuesemes');
        $cwr = ob_get_contents();
        ob_end_clean();
        $pos = strpos($cwr, "[status] => ok");

        if ($pos == 12) {
//		echo "<div style=\"position:absolute;top:100px;left:300px\">Zpr?va byla ?sp?n? odesl?na.<br><a href=\"index.php?sms=ano&typ=jedno\">Poslat dal??</a></div>";
            mssql_connect('10.0.0.20:1433', 'sa', 'heslo22');
            mssql_select_db('sms');
            $today = date("Y-m-d H:i:s");
            $dotaz = mssql_query("insert into sms_log(komu,text,cas,msgid,projekt,pklic,email,status,refmsgid) values ('$kam','$text','" . $today . "','" . $id[1] . "','" . $popis . "','" . $ide . "','" . $email . "','" . $respo . "','" . $refid[1] . "');");
            echo "insert into sms_log(komu,text,cas,msgid,projekt,pklic) values ('$kam','$text','" . $today . "','" . $id[1] . "','" . $popis . "','" . $ide . "');\n\n";
        } else {
            //	echo 'A error occured: ' . $result['error'];
        }
    }
    public function user_sms($sms_kod)
    {

        $cell_phone = $this->mobil();

        $this->odesli_sms("$cell_phone", $sms_kod, "123456", $_POST["login_user"], "420", "email", "");

        // echo "<font color=\"white\">".$sms_kod."</font>";
        ?>
        <div style="position:absolute;left:10px;top:10px;background-image:url(../login3/smskod.png);width:537px;height:395px">
            <div style="position:absolute;left:150px;top:180px;">
                <form name="log_user" method="post">

                    <input type="text" name="sms_kod" value="" style="font-size:25px;">
                    <input type="hidden" name="login_hidden" value="3">
                </form>
            </div>
        </div>
        <?php

    }
    public function logout($cstyle = "")
    {
        ?>
        <form name="unlog_user" method="post" action="<?php echo $this->logout_script ?>"
              target="<?php echo $this->logout_target ?>">
            <input type="submit" value="<?php echo $this->logout_txt ?>" <?php echo $this->logout_style ?>
                   target="parent" onclick="if (confirm('Logout?')) {return true} else {return false} ">
            <input type="hidden" name="login_hidden" value="2">
            <input type="submit" class="btn btn-primary" value="Odhl�sit"/>
        </form>

        <?php
    }
    public function logout_bootstrap(){
        echo '<form name="unlog_user" method="post" action="'.$this->logout_script.'" target="'.$this->logout_target.'">';
        echo '<input type="hidden" name="login_hidden" value="2">';
        echo '<input type="submit" class="btn btn-primary" value="Odhl�sit">';
        echo '<form>';
    }



    public function login_user($login_user, $login_lang, $chyba = ''){
        $remotx = $this->remot();
        $nplat = $this->ntime;
        if ($chyba != '') {
            SetCookie("cipad", $remotx, time() - 18000, "/","comdataczech.cz",0);
            $_COOKIE["cipad"] = "";
        } else {
            SetCookie("cipad", $remotx, time() + $nplat, "/","comdataczech.cz",0);
        }
        ?>
        <html lang="cs-CZ">
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="author" content="116005">
            <title><?php echo $this->nazevaplikace; ?> - P�ihl�en�</title>
            <link href="<?php echo $this->css; ?>" rel="stylesheet">
            <link rel="stylesheet" href="http://10.0.0.157/interni_obj_dev2/vendor/fontawesome-free/css/all.min.css">
            <link rel="stylesheet" href="https://interface.comdataczech.cz/lib/notifications/Lobibox.min.css">
            <link rel="stylesheet" href="https://interface.comdataczech.cz/lib/notifications/notifications.css">
        </head>
        <body>
        <body class="bg-gradient-primary">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-12 col-md-9">
                    <img style="width: 100%; margin-top: 50px;" src="http://10.0.0.157/interni_obj_dev2/img/logomain.png"/>
                    <div class="card o-hidden border-0 shadow-lg my-5">
                        <div class="card-body p-0">
                            <div class="row">
                                <div class="col-lg-6 d-none d-lg-block">
                                    <div class="p-5">
                                        <div class="text-center">
                                            <h1 class="h4 text-gray-900 mb-4"><?php echo $this->nazevaplikace; ?></h1>
                                            <?php echo $this->popisaplikace; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="p-5">
                                        <div class="text-center">
                                            <h1 class="h4 text-gray-900 mb-4">V�tejte zp�t!</h1>
                                        </div>
                                        <form name="log_user" method="post">
                                            <input type="hidden" name="login_hidden" value="1">
                                            <div class="form-group">
                                                <?php
                                                if (isset($this->_lang)) {
                                                    echo '<select class="form-control" name="login_lang">';
                                                    foreach ($this->llist as $ckey => $clang) {
                                                        echo '<option value="' . $ckey . '"';
                                                        if ($ckey == $login_lang) {
                                                            echo " selected ";
                                                        }
                                                        echo '>' . $clang . '</option>';
                                                    }
                                                    echo '</select>';
                                                }
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" name="login_user"
                                                       class="form-control form-control-user"
                                                       placeholder="P�ihla�ovac� jm�no"
                                                       value="<?php echo $login_user; ?>">
                                            </div>
                                            <div class="form-group">
                                                <input type="password" name="login_password"
                                                       class="form-control form-control-user" placeholder="Heslo">
                                            </div>
                                            <input type="submit" name="submit" value="P�ihl�sit"
                                                   class="btn btn-primary btn-user btn-block">
                                            <hr>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://interface.comdataczech.cz/lib/notifications/jquery-1.12.4.min.js"></script>
        <script src="http://10.0.0.157/interni_obj_dev2/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="http://10.0.0.157/interni_obj_dev2/vendor/jquery-easing/jquery.easing.min.js"></script>
        <script src="https://interface.comdataczech.cz/lib/notifications/Lobibox.js"></script>
        <script type="application/javascript">
            window.setTimeout(function () {
                $(".alert").fadeTo(500, 0).slideUp(500, function () {
                    $(this).remove();
                });
            }, 2000);
        </script>
        <?php
        if ($chyba != '' && count($_POST) != 0) {
            if ($chyba == 'bad') {
                ?>
                <script>
                    Lobibox.notify('error', {
                        showClass: 'bounceIn',
                        hideClass: 'bounceOut',
                        msg: '�patn� jm�no nebo heslo.',
                        iconSource: 'fontAwesome'
                    });
                </script>
            <?php
            } else {
            ?>
                <script>
                    Lobibox.notify('error', {
                        showClass: 'bounceIn',
                        hideClass: 'bounceOut',
                        msg: 'V� ��et byl zablokov�n.',
                        iconSource: 'fontAwesome'
                    });
                </script>
                <?php
            }
        }
        ?>
        </body>
        </html>
        <?php
        die;
    }

    public function js_loginf() { // toto pouziva dochina !!
        ?>
        <div id="loginf" style="position:absolute;right:100px;display:none" >
            <input type=text name="this_log_inf" id="this_log_inf" value="<?php echo $this->ntime ?>" >
        </div>
        <script language="javascript">
            <!--
            var ntime="<?php echo $this->ntime ?>" ;
            var ntime=ntime*1

            this_log_inf()

            function this_log_inf() {
                document.getElementById('this_log_inf').value=ntime ;
                ntime=ntime-1;
                if (ntime <= 0 ) {
                    alert('Pozor automaticke odhlaseni, \n  zmacknete konec a prihlase se prosim znovu t')
                    window.open("re_index.php",'win_login',"width=800 height=600 statusbar=true")


                } else{
                    setTimeout("this_log_inf()",1000) ;
                }






            }

            //-->
        </script>

        <?php
    }
    //interni databazove funkce


    public function app_id() {
        $capp = $_SERVER['SCRIPT_NAME']; //old
        $capp = $_SERVER['REQUEST_URI']; //old
        $capp = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $cget = $_GET;
        $cpost= $_POST;
        $cappArr = explode("/",$capp);
        array_pop($cappArr);
        //print_r($cappArr);


        if ($this->avars["$this->id"] * 1 == 0) {
            return 0;
        }

        if (strpos($capp,"/")==0):
            $capp=substr($capp,1);
            //echo $capp;
        endif;

        $capp=eregi_replace("index\.php","",$capp);

        $qapp = "SELECT id,zbytek from doch_t_cis_app_help where active=true and _server = ?";

        $this->doch_init();
        $v_res = $this->db->query_bind($qapp,array($cappArr[0]),array(PDO::PARAM_STR));



        if(count($v_res)==1){
            return $v_res[0]["id"];
        }elseif(count($v_res)>1){
            $selectedAppId = 0;

            for($i=count($cappArr)-1;;$i--){
                $testUrl = array();
                if($i==0){
                    $testUrl[] = '';
                }else{

                    for($j = 0; $j <= $i; $j++) {
                        if ($j != 0) {
                            $testUrl[] = $cappArr[$j];
                        }
                    }
                }

                foreach($v_res as $valdtb){
                    // echo $valdtb["zbytek"]."==".urldecode(implode('/',$testUrl))."<br>";
                    if($valdtb["zbytek"]==urldecode(implode('/',$testUrl))){

                        $selectedAppId = $valdtb["id"];
                        return $selectedAppId;
                    }
                }

            }
        }else{
            return 0;
        }
        return 0;
    }
    public function group_id() {
        $ckey = $this->avars["$this->id"] * 1;
        if ($ckey == 0) {
            return 0;
        }

        $qid = "select zarazeni from doch_t_users2 where user_id = ?";
        $v_res = $this->db->query_bind($qid,array($ckey),array(PDO::PARAM_INT));
        return $v_res[0][0];
        return 0;
    }
    public function user_id()
    {
        $ckey = $this->avars["$this->id"] * 1;
        return $ckey;
    }
    public function mobil()
    {
        $ckey = $this->avars["mobil"];

        return $ckey;
    }

    public function allow() {
        $appid = $this->app_id();
        $groupid = $this->group_id();
        $ckey = $this->avars["$this->id"] * 1;
        $d_level = $this->avars["d_level"] * 1;
        $role = $this->avars["role"] * 1;


        $qallow = "select * from doch_app_allow($appid,$ckey,$groupid,$d_level,$role)";
        //echo $qallow;
        //$v_res = $this->db_query($this->connect, $qallow, $this->dbtype);
        $v_res = $this->db->query($qallow)[0];
        if ($v_res[0] * 1 == 1):
            return true;
        else:
            //echo $qallow;
        endif;
        return false;
    }


    public function allow_list() {
        $appid = $this->app_id();
        $groupid = $this->group_id();
        $ckey = $this->avars["$this->id"] * 1;
        $d_level = $this->avars["d_level"] * 1;
        $role = $this->avars["role"] * 1;

        $qrozcestnik="select url(id) from doch_t_cis_app_help where typ~*'Rozcestnik' limit 1";
        //$v_res = $this->db_query($this->connect, $qrozcestnik, $this->dbtype);
        $v_res = $this->db->query($qrozcestnik);
        $this->logout();
        /*
        foreach($v_res as $row => $ar):
            $curl=$ar[0];
            if ($curl>" "):
                echo "<script>window.open('$curl','rozcestnik')</script>";
                return "";
            endif;
        endforeach;

        $qallow = "select * from (select url(id),*,  doch_app_allow(id,$ckey,$groupid,$d_level,$role) as povolit from doch_t_cis_app_help) a where povolit = 1 and not typ~*'^rozcestnik'";

        //$v_res = $this->db_query($this->connect, $qallow, $this->dbtype);
        $v_res = $this->db->query($qallow);
        foreach ($v_res as $row => $ar):
            echo $ar[2]."-".$ar[0]."<br>";
        endforeach;
        return "";
        */
    }


    public function allow_list_interface() {
        $appid = $this->app_id();
        $groupid = $this->group_id();
        $ckey = $this->avars["$this->id"] * 1;
        $d_level = $this->avars["d_level"] * 1;
        $role = $this->avars["role"] * 1;

        $qallow = "select * from (select url(id),*,  doch_app_allow(id,$ckey,$groupid,$d_level,$role) as povolit from doch_t_cis_app_help) a where povolit = 1 and not typ~*'^rozcestnik'";
        //echo $qallow;
        //$v_res = $this->db_query($this->connect, $qallow, $this->dbtype);
        $v_res = $this->db->query($qallow);
        $n_pole = array();
        foreach ($v_res as $row => $ar):
            if(substr($ar[2],0,10)=='interface-'){
                $ag = explode("-",$ar[2]);
                $retizecek = array();
                foreach($ag as $kej=>$valju){
                    if($kej!=0){
                        $retizecek[] = $valju;
                    }
                }
                $n_pole[] = implode("-",$retizecek);
            }
        endforeach;

        return $n_pole;
    }


    //ZDE JE PROSTOR PRO MRDKY
    public function create_connect()
    {
        switch ($this->dbtype):
            case "ms":
                $this->connect = $this->dbcon_ms();
                break;
            case "pg":
                $this->connect = $this->dbcon_pg();
                break;
            default:
        endswitch;
    }
    public function alter_table() {
        $q[] = " alter table $this->table add $this->dip varchar(50)";
        $q[] = " alter table $this->table add $this->fntime int";
        $q[] = " alter table $this->table add $this->dip varchar(50)";
        if ($this->dbtype == "pg"):
            $q[] = " alter table $this->table add $this->dlogin timestamp without time zone";
        endif;
        if ($this->dbtype == "ms"):

            $q[] = " alter table $this->table add $this->dlogin datetime";
        endif;

        foreach ($q as $cvalue) {

            if ($this->dbtype == "ms"):
                $cvalue = " use $this->dbname;$cvalue  ";
                echo $cvalue;
            endif;
            $v1 = $this->db_query($this->connect, $cvalue, $this->dbtype);
        }
    }
    public function dbcon_ms()
    {
        $con = mssql_connect("$this->dbserver:$this->dbport", "$this->dbuser", "$this->dbpass");
        mssql_query("SET ANSI_NULLS ON", $con);
        mssql_query("SET ANSI_WARNINGS ON", $con);
        //mssql_select_db("$db");
        return $con;
    }
    public function dbcon_pg()
    {
        global $con;

        $pocet_pokusu = 3;

        if (!isset($this->dbport) || empty($this->dbport)):
            $this->dbport = 5432;
        endif;
        $strcon = "host=$this->dbserver port=$this->dbport dbname=$this->dbname user=$this->dbuser password=$this->dbpass";
        //echo $strcon;
        do {
            $con = pg_pconnect($strcon);
            $pocet_pokusu--;
        } while ($pocet_pokusu > 0 or !$con);

        return $con;
    }
    public function pg2msq($q1, $_key)
    {  //sestavi z jednoducheho pg dotazu dotaz ms
        $q = "";
        $q2 = "";
        $q1 = trim($q1);
        $qtmp = eregi_replace("order by ", ";", $q1);
        $qtmp = eregi_replace("limit ", ";", $qtmp);
        $qtmp = eregi_replace("offset ", ";", $qtmp);
        $qtmp = "Select top " . substr($qtmp, 7);

        //$qtmp=eregi_replace("Select ","Select top ",$qtmp);


        $atmp = explode(";", $qtmp);
        $corder = $atmp[1];
        $ctop = "Select top " . $atmp[2];
        $ctop2 = "Select top " . $atmp[3];

        $q = eregi_replace("Select top", $ctop, $atmp[0]);


        if ($atmp[3] > 0):
            $q2 = eregi_replace("Select top", $ctop2, $atmp[0]);
            $n2 = strpos($q2, "from");
            $q2 = substr($q2, $n2 + 5);


            //$q2=eregi_replace("from",";",$q2) ;
            //$atmp1=explode(";",$q2) ;
            //$q2="$ctop2  $_key from ".$atmp1[1];
            //$q2="$ctop2  $_key from ".$atmp[2];
            $q2 .= " order by $corder";
            $q = "$q where $_key not in ($q2) ";
        endif;
        if (!isset($corder) || empty($corder)):
            $corder = $_key;
        endif;
        $q = "$q  order by $corder";

        return $q;
    }
    public function db_query($con, $cq, $xdb="pg") {
        global $dbtype, $con;

        if (!$this->connect):
            //$con = '';
            $this->create_connect();
            $this->connect = $con;

            if(!$this->connect){
                echo "nemam connect";
            }
        endif;



        if (isset($xdb) && $xdb > "")
            $dbtype = $xdb;

        switch ($this->dbtype):
            case ("ms"):


                //$v1 = mssql_query($cq,$con) ;
                $v1 = mssql_query($cq);


                break;
            case ("pg"):



                if (!$v1 = @pg_exec($this->connect, $cq)):

                    echo "Chyba dotazu $cq " . $con . "AAA1".$dbtype;



                endif;

                break;
            case ("my") :
                $v1 = mysql_query($this->connect, $cq);
                break;
        endswitch;
        return $v1;
    }
    public function db_query_pg($con, $cq, $xdb="pg") {
        global $dbtype, $con;

        if (!$this->connect):
            $this->create_connect();
        endif;



        if (isset($xdb) && $xdb > "")
            $dbtype = $xdb;

        switch ($this->dbtype):
            case ("ms"):


                //$v1 = mssql_query($cq,$con) ;
                $v1 = mssql_query($cq);


                break;
            case ("pg"):



                if (!$v1 = @pg_exec($this->connect, $cq)):
                    echo "Chyba dotazu $cq " . $con . "AAA".$dbtype;


                endif;

                break;
            case ("my") :
                $v1 = mysql_query($this->connect, $cq);
                break;
        endswitch;
        return $v1;
    }
    public function db_query0( $cq, $xdb="pg") {




        if (isset($xdb) && $xdb > "")
            $dbtype = $xdb;

        switch ($this->dbtype):
            case ("ms"):


                //$v1 = mssql_query($cq,$con) ;
                $v1 = mssql_query($cq);


                break;
            case ("pg"):



                if (!$v1 = @pg_exec($this->connect, $cq)):
                    echo "Chyba dotazu $cq " . $con . "AAB";


                endif;

                break;
            case ("my") :
                $v1 = mysql_query($this->connect, $cq);
                break;
        endswitch;
        return $v1;
    }
    public function single_array($ar) {
        $ar1 = array();
        $n = 0;
        foreach ($ar as $ckey => $cvalue) {
            if (eregi('[a-z]', $ckey))
                $ar1[] = $cvalue;
        }
        if (count($ar1) == 0)
            $ar1 = $ar;
        return $ar1;
    }
    public function db_fetch_row($v1, $xdb = "pg")
    {

        if (isset($xdb) && $xdb > "")
            $dbtype = $xdb;

        $arl = array();
        if ($dbtype == "ms") :
            $arl = mssql_fetch_array($v1);


        endif;

        if ($dbtype == "pg") :
            $arl = pg_fetch_row($v1);
        endif;
        return $arl;
    }
    public function db_fetch_assoc($v1, $xdb="pg") {

        if (isset($xdb) && $xdb > "")
            $dbtype = $xdb;

        $arl = array();
        if ($dbtype == "ms") :
            $arl = mssql_fetch_assoc($v1);


        endif;

        if ($dbtype == "pg") :
            $arl = pg_fetch_assoc($v1);
        endif;
        return $arl;
    }
    public function db_value($v1, $cname, $ar, $dbtype)
    {
        $cname = strtolower($cname);
        switch ($dbtype):
            case "pg":
                @$cvalue = $ar[pg_field_num($v1, $cname)];
                break;
            case "ms":
                foreach ($ar as $ck => $cv) {

                    if (strtolower($ck) == $cname):
                        $cvalue = $cv;
                        break;
                    endif;
                }
                break;
        endswitch;
        return $cvalue;
    }
    public function db_nvalue($v1, $i, $dbtype) {

        switch ($dbtype):
            case "pg":


                $cvalue = pg_result($v1, $i);

                break;
            case "ms":
                $i1 = 0;
                foreach ($ar as $ck => $cv) {

                    if ($i == $i1):
                        $cvalue = $cv;
                        break;
                    endif;

                    $i1++;
                }
                break;
        endswitch;
        return $cvalue;
    }
    public function db_name($v1, $i, $dbtype) {

        switch ($dbtype):
            case "pg":

                $cvalue = pg_field_name($v1, $i);

                break;
            case "ms":
                $i1 = 0;
                foreach ($ar as $ck => $cv) {

                    if ($i == $i1):
                        $cvalue = $ck;
                        break;
                    endif;

                    $i1++;
                }
                break;
        endswitch;
        return $cvalue;
    }
    public function db_type($v1, $i, $dbtype) {

        switch ($dbtype):
            case "pg":

                $cvalue = pg_field_type($v1, $i);

                break;
            case "ms":
                $i1 = 0;
                foreach ($ar as $ck => $cv) {

                    if ($i == $i1):
                        $cvalue = $ck;
                        break;
                    endif;

                    $i1++;
                }
                break;
        endswitch;
        return $cvalue;
    }
    public function db_size($v1, $i, $dbtype) {
        return db_len($v1, $i, $dbtype);
    }
    public function db_len($v1, $i, $dbtype) {

        switch ($dbtype):
            case "pg":
                //
                $cvalue = pg_field_prtlen($v1, db_name($v1, i, $dbtype));

                break;
            case "ms":
                $i1 = 0;
                foreach ($ar as $ck => $cv) {

                    if ($i == $i1):
                        $cvalue = $ck;
                        break;
                    endif;

                    $i1++;
                }
                break;
        endswitch;
        return $cvalue;
    }
    public function sp_columns1($db, $table, $dbtype, $con, $avz) {
        $aret = array();
        $avz = explode(",", $avz);

        $atmp = sp_columns($db, $table, $dbtype, $con);


        foreach ($avz as $cvalue) {
            foreach ($atmp as $avalue) {

                if (strtoupper($avalue[0]) == strtoupper($cvalue)):
                    $aret[] = $avalue;


                    break;
                endif;
            }
        }


        return $aret;
    }
    public function sp_columns($db, $table, $dbtype, $con1) {
        global $con, $dbtype;
        $atype = array();



        if ($this->dbtype == "ms") :

            mssql_query("USE $db");
            $result2 = mssql_query("EXEC sp_columns @table_name = '$table'");
            $counter = 0;

            while ($row = mssql_fetch_array($result2)):
                $atmp = array();
                $atmp[] = $row["COLUMN_NAME"];
                $atmp[] = $row["TYPE_NAME"] . "(" . $row["LENGTH"] . ")";
                $atmp[] = "w";
                $atype[] = $atmp;
            endwhile;
            mssql_free_result($result2);
        endif;

        if ($this->dbtype == "pg"):
            $tblname = $table . "_strpg";
            //     echo $table."aaaaaaaaaaaaaaaaaaaaaaaaaa";
//      $v1=pg_exec($this->connect,"Select tbl_struct('$table')") ;
//      $v1=pg_exec($this->connect,"Select * from $tblname") ;
            $v1 = pg_exec($this->connect, "Select * from sp_columns('$table')");

            while ($row = pg_fetch_row($v1)) :
                $atmp = array();
                $atmp[] = $row[pg_field_num($v1, "scolumn")];
                $atmp[] = $row[pg_field_num($v1, "type")];
                $atmp[] = "w";
                $atype[] = $atmp;

            endwhile;
            pg_free_result($v1);
        endif;
        return($atype);
    }
    public function is_table($db, $table, $dbtype, $con) {
        global $con, $dbtype;
        $nret = 0;


        if ($dbtype == "ms") :
            mssql_query("USE $db");
            $result2 = mssql_query("EXEC sp_tables ");
            while ($row = mssql_fetch_array($result2)):
                $ctmp = $row["TABLE_NAME"];

                if (strtoupper($ctmp) == strtoupper($table)) :
                    $nret = 1;
                    break;
                endif;


            endwhile;
            @mssql_free_result($result2);
        endif;

        if ($dbtype == "pg"):
            $v1 = pg_exec($con, "Select is_table('$table') as istab");
            while ($row = pg_fetch_row($v1)) :
                $nret = $row[pg_field_num($v1, "istab")];
            endwhile;
        endif;
        pg_free_result($v1);
        return ($nret == 1);
    }
    function connect_log() {

        $strcon = "host=$this->dbserver port=5433 dbname=databaze user=log ";

        $con = pg_pconnect($strcon);
        return $con;

    }

    //Zde kon�� prostor pro mrdky




}
?>
