<?php


class nextCloud{
    public $version = "1.1";
    private $host = "https://cloud.mzda.eu/remote.php/webdav/OKbase";
    private $login = "comdata_okbase";
    private $password = "C0mDat45Okb4e";
    private $handle;

    function __construct()
    {
        if (!function_exists('curl_init')) {
            die('Pro funkci NextCloud třídy je třeba Curl.');
        }
    }

    private function init($host){
        $this->handle = curl_init();
        curl_setopt_array($this->handle,
            array(
                CURLOPT_URL => $host,
                CURLOPT_HTTPAUTH => CURLAUTH_ANY,
                CURLOPT_USERPWD  => "$this->login:$this->password",
                CURLOPT_RETURNTRANSFER   => true,
            )
        );
        curl_setopt($this->handle, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->handle, CURLOPT_SSL_VERIFYPEER, false);
    }


    public function putFile($file,$tName){
        $tmpUrl = $this->host."/".$tName;
        $this->init($tmpUrl);

        $fp = fopen ($file, "r");
        curl_setopt($this->handle, CURLOPT_VERBOSE, 0);
        curl_setopt($this->handle, CURLOPT_URL, $tmpUrl);
        curl_setopt($this->handle, CURLOPT_PUT, 1);
        curl_setopt($this->handle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->handle, CURLOPT_INFILE, $fp);
        curl_setopt($this->handle, CURLOPT_INFILESIZE, filesize($file));

        $result=curl_exec ($this->handle);

        if(curl_error($this->handle)){
            $result = curl_error($this->handle);
            echo $result;
            return false;
        }else{
            curl_close($this->handle);
            return true;
        }

    }


}