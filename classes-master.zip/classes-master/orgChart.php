<?php

class orgChart {
    Private $version = '1.9';
    Private $db;

    public function version(){
        return $this->version;
    }

    function __construct() {
        if (class_exists('db')) {
            $this->db = new db();
            $this->db->server_type = 'PG';
            $this->db->server_address = '10.0.0.57';
            $this->db->server_port = '5432';
            $this->db->server_database = 'recordings';

        }else{
            die("Pro funkčnost je třeba použít třídu DB.");
        }
    }

    public function getBoss($userid,$obdobi){
        if(empty($obdobi)){ return array('Error'=>'Chybí období'); }

        $q_boss = "
                    select user_id, user_lead, divize,jmeno1, user_login(user_lead) as nadrizeny,
                            (select email from doch_t_users2 where user_id = a.user_lead) as email
                                        from (
                                                 select distinct on (a.user_id) a.*,
                                                                b.nazev,
                                                                c.nazev as uct_proj,
                                                                d.jmeno1,
                                                                b.user_lead,
                                                                d.divize
                                                 from (select * from wfm.pa_tym_mem where obdobi_plat @> array ['$obdobi']) a
                                                          join
                                                      wfm.pa_tym b on a.id_tym = b.id
                                                          join wfm.pa_proj c on b.id_pa = c.id
                                                          left join
                                                      wfm.podklad_$obdobi d on b.user_lead = d.user_id1
                                             ) a
                                        where a.user_id = $userid
                ";
        $vysledek = $this->db->query($q_boss);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }

    }


    public function getBossChain($userid,$obdobi){
        if(empty($obdobi)){ return array('Error'=>'Chybí období'); }
        if(empty($userid)){ return array('Error'=>'Chybí userid'); }
        $aktual_user = $userid;
        $leaders = array();
        $stop = 0;
        do {

            $tmp = $this->getBoss($aktual_user,$obdobi);

            if(count($tmp)>0){
                foreach($tmp as $value){
                    if($value["user_lead"]==$aktual_user){
                        $stop = 1;
                    }else{
                        $stop = 0;
                        $leaders[] = $value["user_lead"];
                        $aktual_user = $value["user_lead"];
                    }
                }
            }else{
                $stop = 1;
            }
        } while ( $stop==0 );

        return $leaders;
    }

    public function vypisBossu($userid, $od){
        if(empty($userid)){ return array('Error'=>'Chybí parametr userid'); }
        $q_boss = "
            with t as (
                select unnest(obdobi_plat) as obdobi
                ,a.user_id
                ,CONCAT(dc.prijmeni, ' ',dc.jmeno) as nadrizeny_jmeno
                ,user_login(a.user_id)
                ,user_login(user_lead) as nadrizeny
                ,user_lead
                ,b.nazev
            from wfm.pa_tym_mem a
            join  wfm.pa_tym b on a.id_tym = b.id
            join  public.doch_t_users2 dc on user_lead = dc.user_id
            ) select distinct on (obdobi,user_lead, user_id) * from t
            WHERE user_id = '$userid' and obdobi > '$od'
            order by user_id, obdobi desc
        ";
        $vysledek = $this->db->query($q_boss);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }
    }

    public function allBoss(){
        $allboss = "with t as (
    select unnest(obdobi_plat) as obdobi
         ,user_login(user_lead) as nadrizeny
         ,CONCAT(dc.jmeno, ' ',dc.prijmeni) as jmenonadrizeneho
         ,user_lead
         ,b.nazev
    from wfm.pa_tym_mem a
             join  wfm.pa_tym b on a.id_tym = b.id
             join  public.doch_t_users2 dc on user_lead = dc.user_id
    ) select distinct on (user_lead) * from t";
        $vysledek = $this->db->query($allboss);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }
    }

    public function getTeam($userid,$obdobi){
        $getTeam = " select user_id, user_lead, divize,jmeno1, user_login(user_lead) as nadrizeny
                                        from (
                                                 select distinct on (a.user_id) a.*,
                                                                b.nazev,
                                                                c.nazev as uct_proj,
                                                                d.jmeno1,
                                                                b.user_lead,
                                                                d.divize
                                                 from (select * from wfm.pa_tym_mem where obdobi_plat @> array ['$obdobi']) a
                                                          join
                                                      wfm.pa_tym b on a.id_tym = b.id
                                                          join wfm.pa_proj c on b.id_pa = c.id
                                                          left join
                                                      wfm.podklad_$obdobi d on b.user_lead = d.user_id1
                                             ) a
                                        where a.user_lead = $userid";
        $vysledek = $this->db->query($getTeam);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }
    }

    public function getAllOp($obdobi){
        $getTeam = " select user_id, user_lead, divize,jmeno1, user_login(user_lead) as nadrizeny
                                        from (
                                                 select distinct on (a.user_id) a.*,
                                                                b.nazev,
                                                                c.nazev as uct_proj,
                                                                d.jmeno1,
                                                                d.typ1,                
                                                                b.user_lead,
                                                                d.divize,
                                                                d.xlogin1                
                                                 from (select * from wfm.pa_tym_mem where obdobi_plat @> array ['$obdobi']) a
                                                          join
                                                      wfm.pa_tym b on a.id_tym = b.id
                                                          join wfm.pa_proj c on b.id_pa = c.id
                                                          left join
                                                      wfm.podklad_$obdobi d on b.user_lead = d.user_id1
                                             ) a
                                        where a.typ1 = 'OP'";
        $vysledek = $this->db->query($getTeam);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }
    }

    public function getAll($obdobi,$iZpetne,$withBoss = true){

        if(!is_numeric($iZpetne)){
            return array();
        }
        $q = array();
        $tmp_akt = strtotime($obdobi."01");
        for($i=0;$i<=$iZpetne;$i++){
            $tmp = date('Ym',strtotime('-'.$i.' month',$tmp_akt));
            if(!$withBoss){
                $q[] = "
                    select
                           distinct on (a.user_id1)
                           '$tmp'::text as obdobi,
                           a.user_id1 as user_id,
                           b.user_lead,
                           a.divize,
                           user_full_surname(b.user_lead) as jmeno1,
                           user_login(b.user_lead) as nadrizeny,
                           c.projekt,
                           a.typ1,
                           '' as xlogin1,
                           a.lokalita1,
                           user_okbase_from_id(a.user_id1) as okbase_id,
                           user_login(a.user_id1) as login,
                           doch_oc_company(a.oc1) as firma                                                    
                    from wfm.podklad_$tmp a
                    left join (
                            select * from wfm.pa_tym_mem a
                                join
                                    wfm.pa_tym b on a.id_tym = b.id
                                join wfm.pa_proj c on b.id_pa = c.id
                            where obdobi_plat @> array ['$tmp']
                        ) b on a.user_id1 = b.user_id
                    left join doch_t_users2 c on a.user_id1 = c.user_id;
                ";
            }else {
                $q[] = "
                    select '$tmp'::text as obdobi,a.user_id, user_lead, a.divize,jmeno1, 
                           user_login(user_lead) as nadrizeny,b.projekt,typ1,xlogin1,lokalita1,
                           user_okbase_from_id(a.user_id) as okbase_id,user_login(a.user_id) as login
                           
                    from (
                         select distinct on (a.user_id) a.*,
                                        b.nazev,
                                        c.nazev as uct_proj,
                                        d.jmeno1,
                                        e.typ1,  
                                        e.divize,  
                                        b.user_lead,
                                        d.xlogin1,
                                        e.lokalita1
                         from (select * from wfm.pa_tym_mem where obdobi_plat @> array ['$tmp']) a
                                  join
                              wfm.pa_tym b on a.id_tym = b.id
                                  join wfm.pa_proj c on b.id_pa = c.id
                                  left join
                              wfm.podklad_$tmp d on b.user_lead = d.user_id1
                                  left join
                              wfm.podklad_$tmp e on a.user_id = e.user_id1
                     ) a
                    left join doch_t_users2 b on a.user_id = b.user_id
                
                ";
            }
        }
        $finalQ = implode(" union ",$q);


        $vysledek = $this->db->query($finalQ);
        if(count($vysledek)>0){
            return $vysledek;
        }else{
            return array();
        }
    }

}


