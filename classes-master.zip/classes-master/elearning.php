<?php

class elearning {

    private $version = '1.3';
    private $options = " host='10.0.0.57' port='5432' user='postgres' password='postgres' dbname='recordings' ";
    private $pg_result_conn = "";
    private $SC = "";


    function __construct() {
        $this->pg_result_conn = pg_connect($this->options);
        $this->SC = new SoapClient("https://elearning.comdataczech.cz/FlexiEduServ.asmx?wsdl");
    }

    public function version(){
        return $this->version;
    }

    private function make_list($user_id){
        return "select a.login, a.user_id, b.id, b.typ, b.popis, a.jmeno, a.prijmeni, trim(right(replace(a.mobil, ' ', ''), 9)) as mobil, 
            c.md5heslo,
       case
            when coalesce(trim(a.email),'') = '' then
                case
                    when coalesce(a.email_soukr,'') = '' then concat(a.user_id::text,'@comdataczech.cz')
                    else trim(a.email_soukr)
                end
            else trim(a.email)
            end as email, a.projekt
            from doch_t_users2 a
            left join doch_t_cis_zarazeni b on a.zarazeni = b.id
            left join doch_t_users2_logins c on a.user_id = c.uzivateleid
            where a.user_id = $user_id and a.deleted <> '1' ";
    }

    public function test(){
        try {
            $info = $this->SC->__call("Echo", array());

        } catch (SoapFault $fault) {
            return false;
        }
        return $info;
    }

    public function create($user_id,$id_dc){
        $q_seznam = $this->make_list($user_id);
        $v_dotaz =  pg_query($this->pg_result_conn, $q_seznam);
        if(!$v_dotaz){
            return false;
        }else{
            if(pg_num_rows($v_dotaz)>0){
                $zaznam = pg_fetch_assoc($v_dotaz);
                $sh_param = array(
                    'code' => 'xxx',
                    'userName' => $zaznam["login"],
                    'role' => 'student',
                    'organisation' => 'default',
                    'password' => $zaznam["md5heslo"],
                    'email' => $zaznam["email"],
                    'firstName' => $zaznam["jmeno"],
                    'surName' => $zaznam["prijmeni"],
                    'gender' => 'm',
                    'language' => 'Czech',
                    'isActive' => 1
                );
                $info = $this->SC->__call("UserCreate", array($sh_param));
                if($info->UserCreateResult->Success == 1){
                    $pozice = $this->make_role_id($zaznam["popis"],$zaznam["projekt"]);
                    $this->add_role($zaznam["popis"],$zaznam["projekt"]);

                    $info2 = $this->SC->__call("UserSetPosition", array(array('code'=>'xxx','userName'=> $zaznam["login"],'position' => $pozice)));
                    if($info2->UserSetPositionResult->Success == 1){
                        /* VSE OK */
                        if($id_dc > 0){
                            pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 1, txt_elearning = 'Create OK' where id = ".$id_dc );
                        }
                    }else{
                        /* CREATE ok Position not */
                        if($id_dc > 0){
                            pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = 'Set position fail' where id = ".$id_dc );
                        }
                    }
                }else{
                    if($info->UserCreateResult->Text == 'User exists'){
                        unset($sh_param["role"]);
                        unset($sh_param["organisation"]);
                        $info = $this->SC->__call("UserUpdate", array($sh_param));
                        if($info->UserUpdateResult->Success == 1){
                            $pozice = $this->make_role_id($zaznam["popis"],$zaznam["projekt"]);
                            $this->add_role($zaznam["popis"],$zaznam["projekt"]);

                            $info2 = $this->SC->__call("UserSetPosition", array(array('code'=>'xxx','userName'=> $zaznam["login"],'position' => $pozice)));
                            if($info2->UserSetPositionResult->Success == 1){
                                /* VSE OK */
                                if($id_dc > 0){
                                    pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 1, txt_elearning = 'Create ok (Update)' where id = ".$id_dc );
                                }

                            }else{
                                /* CREATE ok Position not */
                                if($id_dc > 0){
                                    pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = 'Set position fail' where id = ".$id_dc );
                                }
                            }
                        }
                    }else{
                        /* FAIL */
                        if($id_dc > 0){
                            pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = '".($info->UserCreateResult->Text)."' where id = ".$id_dc );
                        }
                    }

                }

                return $info;
            }else{
                return false;
            }
        }
    }

    public function update($user_id,$id_dc){
        $q_seznam = $this->make_list($user_id);
        $v_dotaz =  pg_query($this->pg_result_conn, $q_seznam);
        if(!$v_dotaz){
            return false;
        }else{
            if(pg_num_rows($v_dotaz)>0){
                $zaznam = pg_fetch_assoc($v_dotaz);
                $sh_param = array(
                    'code' => 'xxx',
                    'userName' => $zaznam["login"],
                    'password' => $zaznam["md5heslo"],
                    'email' => $zaznam["email"],
                    'firstName' => $zaznam["jmeno"],
                    'surName' => $zaznam["prijmeni"],
                    'gender' => 'm',
                    'language' => 'Czech',
                    'isActive' => 1
                );
                $info = $this->SC->__call("UserUpdate", array($sh_param));
                if($info->UserUpdateResult->Success == 1){
                    $pozice = $this->make_role_id($zaznam["popis"],$zaznam["projekt"]);
                    $this->add_role($zaznam["popis"],$zaznam["projekt"]);

                    $info2 = $this->SC->__call("UserSetPosition", array(array('code'=>'xxx','userName'=> $zaznam["login"],'position' => $pozice)));
                    if($info2->UserSetPositionResult->Success == 1){
                        /* VSE OK */
                        if($id_dc > 0){
                            pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 1, txt_elearning = 'Update ok' where id = ".$id_dc );
                        }
                    }else{
                        /* UPDATE ok Position not */
                        if($id_dc > 0){
                            pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = 'Set position fail' where id = ".$id_dc );
                        }
                    }
                }else{
                    /* FAIL */
                    if($id_dc > 0){
                        pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = '".($info->UserUpdateResult->Text)."' where id = ".$id_dc );
                    }
                }
                return $info;
            }else{
                return false;
            }
        }

    }

    public function delete($user_id,$id_dc){
        $q_seznam = $this->make_list($user_id);
        $v_dotaz =  pg_query($this->pg_result_conn, $q_seznam);
        if(!$v_dotaz){
            return false;
        }else{
            if(pg_num_rows($v_dotaz)>0){
                $zaznam = pg_fetch_assoc($v_dotaz);
                $sh_param = array(
                    'code' => 'xxx',
                    'userName' => $zaznam["login"],
                    'password' => $zaznam["md5heslo"],
                    'email' => $zaznam["email"],
                    'firstName' => $zaznam["jmeno"],
                    'surName' => $zaznam["prijmeni"],
                    'gender' => 'm',
                    'language' => 'Czech',
                    'isActive' => 0
                );
                $info = $this->SC->__call("UserUpdate", array($sh_param));
                if($info->UserUpdateResult->Success == 1){
                    /* VSE OK */
                    if($id_dc > 0){
                        pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 1, txt_elearning = 'Delete OK' where id = ".$id_dc );
                    }
                }else{
                    /* FAIL */
                    if($id_dc > 0){
                        pg_query($this->pg_result_conn, "update doch_t_users_dc set status_elearning = 2, txt_elearning = '".($info->UpdateResult->Text)."' where id = ".$id_dc );
                    }
                }
                return $info;
            }else{
                return false;
            }
        }

    }

    private function make_role_list(){
        return "
            select a.login, a.user_id, b.id, b.typ, b.popis, a.jmeno, a.prijmeni,
            trim(right(replace(a.mobil, ' ', ''), 9)) as mobil, c.md5heslo, trim(a.email) as email,
            a.projekt
            from doch_t_users2 a
                left join doch_t_cis_zarazeni b on a.zarazeni = b.id
                left join doch_t_users2_logins c on a.user_id = c.uzivateleid
            where a.deleted <> '1' and b.typ is not null and
            exists (select 1 from doch_t_smlouva aa where (_do >= now()::date or _do is null) and aa.user_id = a.user_id) 
            ";
    }

    private function make_role_id($popis,$projekt){
        if(trim($projekt) == ''){
            return $popis.":nezadano";
        }elseif(trim($projekt) == '0'){
            return $popis.":0-REZIE";
        }else{
            return $popis.":".$projekt;
        }

    }

    public function sync_all_role(){
        $seznam = $this->make_role_list();
        $v_dotaz = pg_query($this->pg_result_conn,$seznam);
        if(!$v_dotaz){
            return false;
        }else{
            if(pg_num_rows($v_dotaz)>0){
                while($radek = pg_fetch_assoc($v_dotaz)){
                    $sh_param = array(
                        'code' => 'xxx',
                        'posId' => $this->make_role_id($radek["popis"],$radek["projekt"]),
                        'posName' => $this->make_role_id($radek["popis"],$radek["projekt"])
                    );

                    print_r($sh_param);
                    $info = $this->SC->__call("PositionAdd", array($sh_param));
                    if($info->PositionAddResult->Success == 1){
                        echo $this->make_role_id($radek["popis"],$radek["projekt"])." => vytvoreno\n";
                    }else{
                        echo $this->make_role_id($radek["popis"],$radek["projekt"])." => Jiz existuje\n";
                    }

                }

            }
            return true;
        }

    }

    public function remove_role($popis,$projekt){
        $sh_param = array(
            'code' => 'xxx',
            'position' => $this->make_role_id($popis,$projekt)
        );
        $info = $this->SC->__call("PositionRemove", array($sh_param));
        if($info->PositionRemoveResult->Success == 1){
            return true;
        }else{
            return false;
        }

    }

    public function add_role($popis,$projekt){
        $sh_param = array(
            'code' => 'xxx',
            'posId' => $this->make_role_id($popis,$projekt),
            'posName' => $this->make_role_id($popis,$projekt)
        );
        $info = $this->SC->__call("PositionAdd", array($sh_param));
        if($info->PositionAddResult->Success == 1){
            return true;
        }else{
            return false;
        }
    }


}
