<?php


class myforcePbx
{

    private $version = '1.1';
    private $info_prijemci = array("app_debug@comdataczech.cz");
    private $db;
    private $hlavicka_emailu;
    private $subject_emailu;

    function __construct() {
        if (class_exists('db')) {
            $this->db = new db();
        }else{
            die("Pro funkčnost je třeba použít třídu DB.");
        }
    }

    public function setEmail($email){
        if(!is_string($email)){
            throw new Exception('$email must be a string!');
        }
        $this->info_prijemci[] = $email;
    }

    public function setEmailSubject($subject){
        if(!is_string($subject)){
            throw new Exception('$subject must be a string!');
        }
        $this->subject_emailu = $subject;
    }

    public function setTextEmailu($text_email){
        if(!is_string($text_email)){
            throw new Exception('$text_email must be a string!');
        }
        $this->hlavicka_emailu = $text_email;
    }

    public function version(){
        return $this->version;
    }

    public function posliEmail($telo_emailu){
        if (class_exists('PHPMailer')) {
            $mail = new PHPMailer();
        }else{
            die("Pro funkčnost posli email je třeba mít třídu PHPMailer.");
        }

        $mail->WordWrap = 75;
        $mail->CharSet="UTF-8";
        $mail->IsHTML(true);
        $mail->Subject = $this->subject_emailu;
        $mail->Body = $this->hlavicka_emailu.$telo_emailu;

        foreach($this->info_prijemci as $value){
            $mail->AddAddress($value);
        }

        if(!$mail->Send())
        {
            return false;
        }else{
            return true;
        }
    }

    public function vymazDatZProjektu($projekt,$klice){
        if(empty(trim($projekt))){ die('Musíte zadat projekt.'); }
        $this->db->server_type = 'MS';
        $this->db->server_address = '10.0.0.20';
        $this->db->server_port = '1433';
        $this->db->server_database = $projekt;
        $this->db->connect();

        $dotaz_k_promazani = "update ".$projekt.".dbo.".$projekt." set deleted = 1 where klic in (".(implode(",",$klice)).")";

        $vymaz = $this->db->query($dotaz_k_promazani);
        $vymaz = $this->db->query("select @@ROWCOUNT");

        if(count($vymaz)>0){
            $seznam[$projekt] = count($vymaz);
        }

        return $seznam;
    }

    public function vymazDatZListu($projekt,$klice){
        if(empty(trim($projekt))){ die('Musíte zadat projekt.'); }
        $this->db->server_type = 'MS';
        $this->db->server_address = '10.0.0.21';
        $this->db->server_port = '1433';
        $this->db->server_database = "Lists";
        $this->db->connect();

        $listy_k_procisteni = "select ListID,ListTitle from cca.dbo.lists where ListTitle like '".$projekt."_________%' and CreationTime > dateadd(day,-180,getdate()) ";
        $v_listy = $this->db->query($listy_k_procisteni);
        $seznam = array();
        foreach($v_listy as $value){

            $dotaz_k_promazani = "delete from asklist".$value["ListID"]." output deleted.Klic where Klic in (".(implode(",",$klice)).") ";
            $dotaz_k_promazani_ccdb = "delete from ccdb.listy.dbo.".$value["ListTitle"]." where Klic in (".(implode(",",$klice)).") ";
            //echo $dotaz_k_promazani_ccdb."\n";
            $this->db->query($dotaz_k_promazani_ccdb);
            //echo $dotaz_k_promazani."\n";
            $vymaz = $this->db->query($dotaz_k_promazani);
            if(count($vymaz)>0){
                $seznam[$value["ListTitle"]] =count($vymaz);
            }
        }
        return $seznam;
    }

    public function vymazDatZProjektuAListu($projekt, $podminky=[],$zpetneDni = "180"){
        //priklad promenne podminky: $podminka = array("uvod#int"=>"2,5,null","cislo_smlouvy"=>"6908236483,6908229662,null","databaze#like"=>'Cobrand');
        $this->db->server_type = 'MS';
        $this->db->server_address = '10.0.0.20';
        $this->db->server_port = '1433';
        $this->db->server_database = $projekt;
        $email_text = "";
        $odeslat_email = 0;
        if(empty(trim($projekt))){ die('Musíte zadat projekt.'); }
        if(count($podminky)==0){ die('Musíte zadat podminku výběru dat, například ("cislo_smlouvy#int" => "").'); }

        $podminka = array();
        foreach($podminky as $key => $value){
            $rozdeleni = explode("#",$key);
            $slp_rozdeleni = explode(",",$value);
            if(@$rozdeleni[1]=='int'){
                if(count($slp_rozdeleni)>1){
                    $orpodminka = "";
                    $mezipodminka = array();
                    foreach($slp_rozdeleni as $val2){
                        if($val2=='null'){
                            $orpodminka = " or ".$rozdeleni[0]." is null";
                        }else{
                            $mezipodminka[] = $val2;
                        }
                    }
                    if($orpodminka!=''){
                        $podminka[] = " (".$rozdeleni[0]." in (".(implode(",",$mezipodminka)).") ".$orpodminka.") ";
                    }else{
                        $podminka[] = $rozdeleni[0]." in (".$value.") ";
                    }

                }else{
                    $podminka[] = $rozdeleni[0]." = ".$value." ";
                }
            }elseif(@$rozdeleni[1]=='like'){
                $podminka[] = $rozdeleni[0]." like '%".$value."%' ";
            }else{
                if(count($slp_rozdeleni)>1){
                    $orpodminka = "";
                    $mezipodminka = array();
                    foreach($slp_rozdeleni as $val2){
                        if($val2=='null'){
                            $orpodminka = " or ".$rozdeleni[0]." is null";
                        }else{
                            $mezipodminka[] = $val2;
                        }
                    }
                    if($orpodminka!=''){
                        $podminka[] = " (".$rozdeleni[0]." in ('".(implode("','",$mezipodminka))."') ".$orpodminka.") ";
                    }else{
                        $podminka[] = $rozdeleni[0]." in ('".(implode("','",$slp_rozdeleni))."') ";
                    }

                }else{
                    $podminka[] = $rozdeleni[0]." = '".$value."' ";
                }
            }
        }

        $balik_dat = "select Klic from ".$projekt.".dbo.".$projekt." where e_date > dateadd(day,-$zpetneDni,getdate()) and ".(implode(" and ",$podminka));
        $v_balik_dat = $this->db->query($balik_dat);
        $klice = array();
        if(count($v_balik_dat)>0){
            foreach($v_balik_dat as $value){
                $klice[] = $value["Klic"];
            }

            $vysledek_listu = $this->vymazDatZListu($projekt,$klice);
            $email_text .= "<br>Je potřeba aktualizovat tyto listy : <br>";
            if(count($vysledek_listu)>0){
                foreach($vysledek_listu as $kkey => $vvalue){
                    $email_text .= "list : ".$kkey." => ".$vvalue."<br>";
                }
                $odeslat_email = 1;
            }


            $vysledek_projektu = $this->vymazDatZProjektu($projekt,$klice);
            if(count($vysledek_projektu)>0){
                $odeslat_email = 1;
            }

            $email_text .= "<br>Z projektu ".$projekt." bylo vymazáno ".(count($klice))." dat.<br>";

            if($odeslat_email==1){
                $this->posliEmail($email_text);
            }

            return 'Hotovo';

        }else{
            return "Neni co mazat.";
        }

    }
}