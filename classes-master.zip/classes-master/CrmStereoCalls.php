<?php


class CrmStereoCalls
{
    private $verze = '1.0';
    public $datum;
    public $partner;
    private $tmp_values;
    private $db;
    private $client_id;  // konkrétně pro UPC
    private $oddelovac = "_";
    private $jmennaKonvence = [
        "jmenoop"=>true,
        "datum_hovoru"=>true,
        "telefon"=>true
    ];
    private $predefinedKonvence = [
        "jmenoop"=>"unaccent(trim(u.prijmeni) || trim(u.jmeno))",
        "client_id"=>"fce:vrat_client_id",
        "datum_hovoru"=>"replace(replace(h.zacatek::timestamp(0)::text,' ','_'),':','-')",
        "telefon"=>"right(telefon,9)",
        "UPCnazev"=>"fce:vrat_upc_nazev#uzivatel_pk",
        "UPCpobocka"=>"fce:vrat_upc_pobocka#uzivatel_pk"
    ];

    function __construct()
    {
        if (class_exists('db')) {
            $this->db = new db();
            $this->db->server_type = 'PG';
            $this->db->server_address = "10.0.0.160";
            $this->db->server_port = "5432";
            $this->db->server_database = "crm";
        } else {
            die("Pro funkčnost je třeba použít třídu DB.");
        }

        $this->setDatum(date("Ymd"));

    }

    public function setDatum(string $datum){
        if(is_numeric($datum)===false){
            throw new Exception("Datum musí být ve formátu YYYYMMDD!");
        }else{
            $this->datum = trim($datum);
        }
    }

    public function setPartnerId(int $partnerId){
        $this->partner = $partnerId;
    }


    public function setKonvence(array $konvence,string $oddelovac = "_"){
        $this->jmennaKonvence = $konvence;
        $this->oddelovac = $oddelovac;
    }

    public function getStereoCalls(){
        $listOfCalls = [];
        if($this->partner === null || is_numeric($this->partner)===false){
            throw new Exception("PartnerID musí být vyplněno a musí to být číslo.");
        }

        $i = 0;
        foreach($this->getSql() as $value){
            $this->tmp_values["uzivatel_pk"] = $value["uzivatel_pk"];
            $listOfCalls[$i]["zdrojovySoubor"] = $this->getNazevSouboru($value["record_nahravka"]);
            $listOfCalls[$i]["cilovySoubor"] = $this->getNazevCilovehoSouboru($value["hovor_pk"]);
            $listOfCalls[$i]["datumHovoru"] = $value["record_zacatek"];
            $listOfCalls[$i]["hovor_pk"] = $value["hovor_pk"];
            $listOfCalls[$i]["obchodni_pripad_pk"] = $value["obchodni_pripad_pk"];
            $i++;
        }

        return $listOfCalls;
    }

    private function getSql(){

        $od = $this->datum." 00:00:00";
        $do = $this->datum." 23:59:59";

        $q = "  select * from hovor h 
                join uzivatel u on u.uzivatel_pk = h.uzivatel_pk
                where h.zacatek between ?::timestamptz and ?::timestamptz and h.produkt_id in (
                    select produkt_id from produkt where partner_pk = ?
                )
                and h.record_trvani_hovoru > 0 and h.record_nahravka is not null limit 10 offset 100

             ";

        $res = $this->db->query_bind($q,[$od,$do,$this->partner],[PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_INT]);

        if(is_array($res)){
            return $res;
        }

        return [];

    }

    public function getNazevCilovehoSouboru(int $hovor_pk){
        $finalniKonvenceSql = [];
        foreach($this->jmennaKonvence as $key=>$value){
            if(is_bool($value)){
                if($value===true){
                    if(array_key_exists($key,$this->predefinedKonvence)){
                        if(substr($this->predefinedKonvence[$key],0,4)==="fce:"){
                            $fce = str_replace("fce:","",$this->predefinedKonvence[$key]);
                            $roz = explode("#",$fce);
                            $fceName = $roz[0];


                            if(method_exists($this,$fceName)){

                                if(count($roz)>1){

                                    $finalniKonvenceSql[] = "'".$this->$fceName($this->tmp_values[$roz[1]])."'";
                                }else{
                                    $finalniKonvenceSql[] = "'".$this->$fceName()."'";
                                }

                            }
                        }else{
                            $finalniKonvenceSql[] = $this->predefinedKonvence[$key];
                        }
                    }
                }
            }else{
                $finalniKonvenceSql[] = "'".$value."'";
            }
        }

        $q_nazev = "select ".implode(" || '".$this->oddelovac."' || ",$finalniKonvenceSql)."::text as nazev_cile from hovor h join uzivatel u on u.uzivatel_pk = h.uzivatel_pk where hovor_pk = ?";
        $res = $this->db->query_bind($q_nazev,[$hovor_pk],[PDO::PARAM_INT]);

        return $res[0]["nazev_cile"].".wav";

    }

    private function getNazevSouboru(string $cesta){
        $stereoPath = str_replace("-linuxbox",
                                "/mnt/nahravky/81.31.47.136_docasne_zalohy_wav/mnt/nahravky/81.31.47.136",
                                $cesta);
        $stereoPath = str_replace(".mp3",".wav.done",$stereoPath);
        return $stereoPath;
    }

    private function vrat_client_id(){

        if($this->client_id===null){
            $lastID = $this->db->query_bind(
                "select max(client_id) as client_id from log_stereo_nahravek where date_part('year',datum_prenosu::date)::text || lpad(date_part('month',datum_prenosu::date)::text,2,'0') = ?",
                [substr($this->datum,0,6)],
                [PDO::PARAM_STR]
            );

            if(is_numeric($lastID[0]["client_id"])){

                $this->client_id = (int) $lastID[0]["client_id"];
            }else{
                $this->client_id = 0;
            }
        }
        $this->client_id++;

        return str_pad($this->client_id,6,"0",STR_PAD_LEFT);
    }

    private function vrat_upc_nazev(int $uzivatel_pk){
        $pobocka = $this->db->query_bind(
            "select stredisko_uzivatele_vrat(?::int,?::int) as pobocka;",
            [$uzivatel_pk,substr($this->datum,0,6)],
            [PDO::PARAM_INT,PDO::PARAM_STR]
        );

        if($pobocka[0]["pobocka"]=='HK'){
            return "comdatahradeckraloveict";
        }else{
            return "comdataostravaict";
        }
    }

    private function vrat_upc_pobocka(int $uzivatel_pk){
        $pobocka = $this->db->query_bind(
            "select stredisko_uzivatele_vrat(?::int,?::int) as pobocka;",
            [$uzivatel_pk,substr($this->datum,0,6)],
            [PDO::PARAM_INT,PDO::PARAM_STR]
        );

        if($pobocka[0]["pobocka"]=='HK'){
            return "ComdataHradecKralove";
        }else{
            return "ComdataOstrava";
        }
    }

    public function logPrenos(array $hodnoty){
        $q = "insert into log_stereo_nahravek(datum_prenosu,".implode(', ',array_keys($hodnoty)).")
        values (now(),".implode(', ',array_fill(0,count($hodnoty),'?')).")
        ";

        $datove_typy = [];
        foreach($hodnoty as $val){
            if(gettype($val) === 'integer'){
                $datove_typy[] = PDO::PARAM_INT;
            }else{
                $datove_typy[] = PDO::PARAM_STR;
            }
        }
//        echo $q.PHP_EOL;
//        var_dump($hodnoty);
//        var_dump($datove_typy);

        $this->db->query_bind($q,array_values($hodnoty),$datove_typy);


    }

}