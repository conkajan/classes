<?php


class ProfiSms{

    /**
     * @var string
     */
    private $version = '1.4';
    /**
     * @var db
     */
    private $db;
    /**
     * @var ApiClient
     */
    private $smsAPI;
    /**
     * @var string
     */
    private $apiLogin = "comdata_twoway";
    /**
     * @var string
     */
    private $apiPassword = "7uwrprvx";

    /**
     * Seznam čísel od providera
     * @var string[]
     */
    private $supportedNumbers = ["+420790865034","+421940682103"];

    /**
     * Seznam povolených předvoleb
     * @var string[]
     */
    private $supportedPrefix = ["+420","+421"];

    /**
     * ProfiSms constructor.
     */
    public function __construct()
    {

        try{
            $this->db = new db();
        }catch (Throwable $e) {
            echo 'Je vyžadována třída db';
            die();
        }

        $this->db->server_type = 'MS';
        $this->db->server_address = '10.0.0.20';
        $this->db->server_port = '1433';
        $this->db->server_database = 'profi_sms';

        try{
            $this->smsAPI = new ApiClient();
        }catch (Throwable $e) {
            echo 'Je vyžadována třída ApiClient';
            die();
        }

        $this->smsAPI->endpoint = "https://api.profisms.cz";
        //$this->smsAPI->endpoint = "http://127.0.0.1:1500";
        $this->smsAPI->metoda = 'POST';
        //$this->smsAPI->header["Content-Type"] = "application/json";

    }

    /**
     * Nastavení testovacího režimu
     */
    public function setTestUser(){
        $this->apiLogin = "user";
        $this->apiPassword = "passwd";
    }


    /**
     * Test funkčnosti spojení
     * @return bool
     */
    public function test(){
        $request = [];
        $request["CTRL"] = "test";
        $request["_login"] = $this->apiLogin;
        $request["_service"] = "general";
        $_call = $this->prepareRequest($this->smsAPI->endpoint." ".json_encode($request));
        $request["_call"] = $_call;
        $request["_password"] = $this->getPassword($_call);
        $this->smsAPI->params["content"] = http_build_query($request);
        $response = $this->smsAPI->request();
        $this->saveResponse($_call,$response);

        if($response){
            $response = json_decode($response);
            if(isset($response->error->message) and $response->error->message==="OK"){
                return true;
            }
        }

        return false;
    }

    /**
     * Odeslání SMS (Podporuje pouze single SMS)
     * @param $text
     * @param $telefon
     * @param string $sender
     * @return bool
     */
    public function sendSms($text, $telefon, $sender = ""){
        if(!in_array($sender,$this->supportedNumbers)){
            $sender = $this->supportedNumbers[0];
        }

        if(!$this->prefixValidation($telefon)){
            throw new RuntimeException("Neplatný prefix.");
        }

        $request = [];
        $request["CTRL"] = "sms";
        $request["_login"] = $this->apiLogin;
        $request["_service"] = "sms";
        $request["text"] = $text;
        $request["split"] = "concat";
        $request["msisdn"] = $telefon;
        $request["source"] = $sender;
        $_call = $this->prepareRequest($this->smsAPI->endpoint." ".json_encode($request));
        $request["_call"] = $_call;
        $request["_password"] = $this->getPassword($_call);

        $idOdchozi = $this->prepareSMS($text,$telefon,$sender,$_call);

        $this->smsAPI->params["content"] = http_build_query($request);
        $response = $this->smsAPI->request();

        $this->saveResponse($_call,$response);

        if($response){
            $response = json_decode($response);
            $this->updateSMS($idOdchozi,$response);
            if(isset($response->error->message) && $response->error->message==="OK"){
                return true;
            }
        }else{
            $this->updateSMS($idOdchozi,"");
        }

        return false;
    }

    /**
     * Vložení requestu do DTB a získání ID pro vytvoření Hesla a callid.
     * @param string $requestString
     * @return mixed
     */
    private function prepareRequest(string $requestString){
        $res = $this->db->query_bind(
                "insert into api_calls(request) OUTPUT Inserted.ID values (?); ",
                [$requestString],
                [PDO::PARAM_STR]
        );
        if(is_array($res) && isset($res[0]["ID"])){
            return $res[0]["ID"];
        }else{
            throw new \RuntimeException("Nepodařilo se získat _call ID z tabulky api_calls.");
        }
    }

    /**
     * Metodu pro vrácení hesla
     * @param int $_call
     * @return string
     */
    private function getPassword(int $_call){
        return md5(md5($this->apiPassword).$_call);
    }


    /**
     * Funkce pro validaci spravne zadaneho prefixu
     * @param string $number
     * @return bool
     */
    private function prefixValidation(string $number){
        $result = false;
        foreach($this->supportedPrefix as $value){
            if($value==substr($number,0,strlen($value))){
                $result = true;
            }
        }

        return $result;
    }

    /**
     * Zapsání vysledku requestu
     * @param int $_call
     * @param string $response
     */
    private function saveResponse(int $_call, string $response){
        $q = "update api_calls set response = ? where id = ?";
        $this->db->query_bind($q,[$response,$_call],[PDO::PARAM_STR,PDO::PARAM_INT]);
    }

    /**
     * Zápis odchozí sms a získání Callid
     * @param string $text
     * @param string $telefon
     * @param string $sender
     * @param int $_call
     * @return mixed
     */
    private function prepareSMS(string $text, string $telefon, string $sender, int $_call){
        $res = $this->db->query_bind(
            "insert into api_sms_odchozi(text_sms,status_sms,sender,telefon,api_calls_id) OUTPUT Inserted.ID values (?,'Odesílání',?,?,?); ",
            [iconv("UTF-8","WINDOWS-1250",$text),$sender,$telefon,$_call],
            [PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_INT]
        );
        if(is_array($res) && isset($res[0]["ID"])){
            return $res[0]["ID"];
        }else{
            throw new \RuntimeException("Nepodařilo se získat ID z tabulky api_sms_odchozi.");
        }
    }

    /**
     * Aktualizace odchozí sms po requestu
     * @param int $idOdchozi
     * @param $response
     */
    private function updateSMS(int $idOdchozi, $response){

        if(isset($response->error->message) && $response->error->message==="OK"){

            $qUpdate = "update api_sms_odchozi set 
                           status_sms = 'Odeslano', 
                           cas_aktualizace = getdate(),
                           invalid_numbers = ?,
                           currency = ?,
                           cena = ?,
                           cena_dph = ?,
                           klic = ?,
                           pocet_casti = ?,
                           id_sms = ?
                           where id = ?
                           ";
            $resU = $this->db->query_bind($qUpdate,
                [   $response->data->invalid,
                    $response->data->currency,
                    (float) $response->data->price,
                    (float) $response->data->pricevat,
                    $response->_key,
                    $response->data->partsCount,
                    $response->data->sms[0]->id,
                    $idOdchozi],
                [   PDO::PARAM_STR,
                    PDO::PARAM_STR,
                    PDO::PARAM_STR,
                    PDO::PARAM_STR,
                    PDO::PARAM_STR,
                    PDO::PARAM_INT,
                    PDO::PARAM_STR,
                    PDO::PARAM_INT]
            );
        }else{
            $qUpdate = "update api_sms_odchozi set status_sms = ? where id = ?";
            $resU = $this->db->query_bind($qUpdate,
                ["Chyba({$response->error->message})",$idOdchozi],
                [PDO::PARAM_STR,PDO::PARAM_INT]
            );
        }
    }

    /**
     * Fetch příchozích zpráv
     * @param string $date
     * @return bool
     */
    public function getIncoming(string $date){

        if(!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$date))
        {
           throw new RuntimeException("Datum není ve správném formátu");
        }

        $request = [];
        $request["CTRL"] = "sms_in";
        $request["_login"] = $this->apiLogin;
        $request["_service"] = "sms";
        $_call = $this->prepareRequest($this->smsAPI->endpoint." ".json_encode($request));
        $request["_call"] = $_call;
        $request["_password"] = $this->getPassword($_call);
        $request["from"] = $date;
        $this->smsAPI->params["content"] = http_build_query($request);


        $response = $this->smsAPI->request();


        if($response){
            $response = json_decode($response);

            if(isset($response->error->message) && $response->error->message==="OK"){
                foreach($response->data as $value){

                    $exist = "select count(*) as pocet from api_sms_prichozi where id_sms = ?";
                    $resEx = $this->db->query_bind($exist,[$value->id],[PDO::PARAM_INT]);
                    if($resEx[0]["pocet"]===0){

                           $newDate = date("m.d.Y H:i:s", strtotime($value->created));

                           $ins = "insert into api_sms_prichozi(id_sms,recipient,msisdn,created,text_sms,id_smsout) values (?,?,?,?,?,?)";
                           $resIns = $this->db->query_bind(
                               $ins,
                               [
                                   $value->id,
                                   $value->recipient,
                                   $value->msisdn,
                                   $newDate,
                                   $value->text,
                                   json_encode($value->id_smsout)
                               ],
                               [
                                   PDO::PARAM_STR,
                                   PDO::PARAM_STR,
                                   PDO::PARAM_STR,
                                   PDO::PARAM_STR,
                                   PDO::PARAM_STR,
                                   PDO::PARAM_STR
                               ]

                           );
                    }

                }

                return true;
            }
        }

        return false;

    }

    /**
     * Získání doručenek od zadaného datumu
     * @param string $date
     */
    public function getInfoSMS(string $date){
        if(!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$date))
        {
            throw new RuntimeException("Datum není ve správném formátu");
        }

        $overList = "select id,id_sms from api_sms_odchozi where cast(cas_vlozeni as date) >= cast(? as date) and id_sms is not null ";
        $resOv = $this->db->query_bind($overList,[$date],[PDO::PARAM_STR]);
        $request = [];
        $request["CTRL"] = "sms_info";
        $request["_login"] = $this->apiLogin;
        $request["_service"] = "sms";

        foreach($resOv as $value){
            $_call = $this->prepareRequest($this->smsAPI->endpoint." ".json_encode($request));
            $request["_call"] = $_call;
            $request["_password"] = $this->getPassword($_call);
            $request["id"] = $value["id_sms"];
            $this->smsAPI->params["content"] = http_build_query($request);

            $response = $this->smsAPI->request();
            if($response){
                $response = json_decode($response);
                if(isset($response->error->message) && $response->error->message==="OK"){
                    $update = "update api_sms_odchozi set info_delivery = ?, info_state = ?, info_delivered = ? where id = ?";
                    $newDate = '';
                    if(!empty($response->data->delivered)) {
                        $newDate = date("m.d.Y H:i:s", strtotime($response->data->delivered));
                    }
                    $resUpd = $this->db->query_bind($update,
                        [$response->data->delivery,$response->data->state,$newDate,$value["id"]],
                        [PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_STR,PDO::PARAM_INT]
                    );
                }
            }

        }

    }

    /**
     * Výpis sms
     * @param string $type
     * @param array $dateRange
     * @param string $from
     * @param string $to
     * @param string $text
     * @return array|false
     */
    public function getListSMS(string $type, array $dateRange = [], string $from = "", string $to="", string $text="", int $pmiUserId = null){

        $podminky = [];
        $params = [];
        $paramsType = [];

        if($type!='out' && $type!='in'){
            throw new RuntimeException("Type musí být 'out' nebo 'in'");
        }

        if(count($dateRange)===0 && empty($from) && empty($to) && empty($text)){
            throw new RuntimeException("Musí být vyplněn alespoň jeden parametr");
        }

        if(count($dateRange)>0){
            if(
                !preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$dateRange[0]) ||
                (isset($dateRange[1]) && !preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$dateRange[1]))
            )
            {
                throw new RuntimeException("Datum není ve správném formátu");
            }

            $fromD = date("Y-m-d 00:00:00", strtotime($dateRange[0]));
            if(isset($dateRange[1])){
                $toD = date("Y-m-d 23:59:59", strtotime($dateRange[1]));
            }else{
                $toD = date("Y-m-d 23:59:59", strtotime($dateRange[0]));
            }

            if($type==='out'){
                $podminky[] = "api_sms_odchozi.cas_vlozeni between cast(? as datetime) and cast(? as datetime)";
            }else{
                $podminky[] = "api_sms_prichozi.created between cast(? as datetime) and cast(? as datetime)";
            }

            $params[] = $fromD;
            $paramsType[] = PDO::PARAM_STR;
            $params[] = $toD;
            $paramsType[] = PDO::PARAM_STR;

        }

        if(!empty($text)){
            $podminky[] = "text_sms like ?";
            $params[] = '%'.$text.'%';
            $paramsType[] = PDO::PARAM_STR;
        }

        if(!empty($from)){
            if($type==='out') {
                $podminky[] = "sender like ?";
            }else{
                $podminky[] = "msisdn like ?";
            }
            $params[] = '%'.$from.'%';
            $paramsType[] = PDO::PARAM_STR;
        }

        if(!empty($to)){
            if($type==='out') {
                $podminky[] = "telefon like ?";
            }else{
                $podminky[] = "recipient like ?";
            }
            $params[] = '%'.$to.'%';
            $paramsType[] = PDO::PARAM_STR;
        }

        $pmiAddon = "";


        if($type==='out'){
            if($pmiUserId>=0 && is_numeric($pmiUserId)){
                $pmiAddon = "inner join karty.dbo.pmi_tasklist b on 
                    api_sms_odchozi.telefon = case when left(b.telefon,4) = '+421' then rtrim(b.telefon) else '+420' + right(b.telefon,9) end";
                if($pmiUserId>0){
                    $podminky[] = "b.uzivateleid = ?";
                    $params[] = $pmiUserId;
                    $paramsType[] = PDO::PARAM_INT;
                }
            }
            $select = "select * from api_sms_odchozi {$pmiAddon} where ".implode(" and ",$podminky);
        }else{
            if($pmiUserId>=0 && is_numeric($pmiUserId)){
                $pmiAddon = "inner join karty.dbo.pmi_tasklist b on api_sms_prichozi.msisdn = case when left(b.telefon,4) = '+421' then rtrim(b.telefon) else '+420'+right(b.telefon,9) end";
                if($pmiUserId>0){
                    $podminky[] = "b.uzivateleid = ?";
                    $params[] = $pmiUserId;
                    $paramsType[] = PDO::PARAM_INT;
                }
            }
            $select = "select * from api_sms_prichozi {$pmiAddon} where ".implode(" and ",$podminky);
        }


//        var_dump($params);
//
//        echo $select.PHP_EOL;
//        die();


        $res = $this->db->query_bind($select,$params,$paramsType);

        if(is_array($res)){
            return $res;
        }

        return [];
    }

    /**
     * Nápověda
     */
    public function help(){
        echo "Nápověda k použití :".PHP_EOL;
        echo 'require("/root/scripts/class/DB.php");'.PHP_EOL;
        echo 'require("/root/scripts/class/ApiClient.php");'.PHP_EOL;
        echo 'require("/root/scripts/class/ProfiSms.php");'.PHP_EOL.PHP_EOL;
        echo '$test = new ProfiSms();'.PHP_EOL.PHP_EOL;

        echo 'Pro testovani je mozne nastavit debug usera (nedojde k odeslani SMS) :'.PHP_EOL;
        echo '$test->setTestUser();'.PHP_EOL.PHP_EOL;

        echo 'Pro otestovani spojeni s ProfiSms se pouziva :'.PHP_EOL;
        echo '$test->test(); Vraci true nebo false'.PHP_EOL.PHP_EOL;

        echo 'Pro odeslani SMS :'.PHP_EOL;
        echo '$test->sendSms("test","+420605205768"); Vraci true nebo false'.PHP_EOL;
        echo 'Mozno pouzit i parametr sender $test->sendSms("test","605205768","+421940682103"); Vraci true nebo false'.PHP_EOL.PHP_EOL;

        echo 'Pro synchronizaci příchozích SMS od zadaného data :'.PHP_EOL;
        echo '$test->getIncoming("2020-12-07"); Vraci true nebo false'.PHP_EOL.PHP_EOL;

        echo 'Pro synchronizaci doručenek a stavu SMS od zadaného data :'.PHP_EOL;
        echo '$test->getInfoSMS("2020-12-07"); Vraci true nebo false'.PHP_EOL.PHP_EOL;

        echo 'Pro vypsani prichozich nebo odchozich sms :'.PHP_EOL;
        echo '$test->getListSMS("in",["2020-12-07"]); Vraci array se vypisem'.PHP_EOL.PHP_EOL;

        echo 'Vsechny parametry pro vypsani zprav (Je mozne libovolne kombinovat) :'.PHP_EOL;
        echo 'Param1 = type : string "out" nebo "in" (prichozi nebo odchozi)'.PHP_EOL;
        echo 'Param2 = daterange : array ["from(YYYY-MM-DD)","to(YYYY-MM-DD)"] (muze byt pouze from, tim to vybere za jeden den)'.PHP_EOL;
        echo 'Param3 = from : string "605205768" (vse se hleda fulltext neni nutna predvolba)'.PHP_EOL;
        echo 'Param4 = to : string "605205768" (vse se hleda fulltext neni nutna predvolba)'.PHP_EOL;
        echo 'Param5 = text : string "Ahoj" (vse se hleda fulltext )'.PHP_EOL.PHP_EOL;
        echo 'Param6 = pmiUserId : int "Specialni parametr pro projekt PMI, při parametru 0 vypisuje vše'.PHP_EOL.PHP_EOL;
    }

}
