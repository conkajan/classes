<?php

class ApiClient {
        Private $version = '1.4';
        Private $conn;
        Public $metoda = 'GET';
        Public $endpoint = "";
        Public $kodovani = "UTF-8";
        Public $header_separator = "\r\n";
        Public $header = array();
        Public $params = array();
        Public $ignore_errors = false;

        private function recodes($vstup){
            return iconv('UTF-8',$this->kodovani,$vstup);

        }

        public function version(){
            return $this->version;
        }

        public function request(){

            if($this->endpoint == ''){
                return $this->recodes('Je potřeba vyplnit endpoint');
            }
            $builded_header = "";

            foreach($this->header as $key=>$value){
                $builded_header .= $key.": ".$value.$this->header_separator;
            }

            if($this->metoda == 'GET'){
                $opts = array('http' =>
                    array(
                        'method'  => 'GET',
                        'ignore_errors'  => $this->ignore_errors,
                        'header' => trim($builded_header),
                        'timeout' => 60
                    )
                );
                if(count($this->params) > 0){
                    foreach($this->params as $id_param => $val_param){
                        $opts["http"][$id_param] = $val_param;
                    }
                }
            }elseif($this->metoda=='POST'){
                $opts = array('http' =>
                    array(
                        'method'  => 'POST',
                        'ignore_errors' => $this->ignore_errors,
                        'header' => trim($builded_header),
                        'timeout' => 60
                    )
                );
                if(count($this->params) > 0){
                    foreach($this->params as $id_param => $val_param){
                        $opts["http"][$id_param] = $val_param;
                    }
                }
            }else{
                return 'Metoda '.$this->metoda.' není implementovaná.';
            }

            $context  = stream_context_create($opts);
            $result = file_get_contents($this->endpoint, false, $context);
            if($result){
                return $result;
            }else{

                return false;
            }


        }

}


?>