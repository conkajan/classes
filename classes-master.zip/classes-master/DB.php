<?php

class db {
    private $version = '3.1';
    public $server_type = '';
    public $server_address = '';
    public $server_port = '';
    public $server_database = '';
    public $options = array();
    public $charsetConn = '';
    private $conn;
    private $support_types = array(PDO::PARAM_STR,PDO::PARAM_INT,PDO::PARAM_BOOL,PDO::PARAM_NULL);
    private $fetchModes = array(PDO::FETCH_ASSOC,PDO::FETCH_BOTH);

    public function connect() {

        if($this->server_type==''){
            die('Musíš nastavit typ SQL (MS nebo PG).');
        }

        if($this->server_address==''){
            die('Musíš nastavit IP adresu databáze.');
        }

        if($this->server_port==''){
            die('Musíš nastavit PORT databáze.');
        }

        if($this->server_database==''){
            die('Musíš nastavit jméno databáze.');
        }

        try
        {
            if($this->server_type == 'MS') {
                if($this->server_address=='10.0.0.63\SQLEXPRESS'){
                    $pass = "Admin123";
                    $this->conn = new PDO("dblib:".(isset($this->charsetConn) && !empty($this->charsetConn) ? 'charset='.$this->charsetConn.';' : '')."host=".$this->server_address.";port=".$this->server_port." ;dbname=".$this->server_database, "sa", $pass);
                }elseif($this->server_address=='10.0.0.41\SQLEXPRESS'){
                    $pass = "Serviska971/";
                    $this->conn = new PDO("dblib:".(isset($this->charsetConn) && !empty($this->charsetConn) ? 'charset='.$this->charsetConn.';' : '')."host=".$this->server_address.";port=".$this->server_port." ;dbname=".$this->server_database, "admin", $pass);
                }else{
                    $pass = "heslo22";
                    $this->conn = new PDO("dblib:".(isset($this->charsetConn) && !empty($this->charsetConn) ? 'charset='.$this->charsetConn.';' : '')."host=".$this->server_address.";dbname=".$this->server_database.";port=".$this->server_port, "sa", $pass);
                }
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->query('SET ANSI_NULLS ON');
                $this->query('SET ANSI_WARNINGS ON');

                if(count($this->options)>0){
                    foreach($this->options as $oVal){
                        $this->query('SET '.$oVal.' ON');
                    }
                }

            }elseif($this->server_type == 'PGbb'){
                $this->conn = new PDO("pgsql:host=".$this->server_address.";port=".$this->server_port.";dbname=".$this->server_database.";user=dbclass;password=jHujkeKsssFF48158");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }elseif($this->server_type == 'PG'){
                $this->conn = new PDO("pgsql:host=".$this->server_address.";port=".$this->server_port.";dbname=".$this->server_database.";user=postgres;password=potgres");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }elseif($this->server_type == 'PGcrm'){
                $this->conn = new PDO("pgsql:host=".$this->server_address.";port=".$this->server_port.";dbname=".$this->server_database.";user=repad");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }elseif($this->server_type == 'PGstudio'){
                $this->conn = new PDO("pgsql:host=".$this->server_address.";port=".$this->server_port.";dbname=".$this->server_database.";user=postgres;password=maix-minus971/");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }elseif($this->server_type == 'PGLbstat'){
                $this->conn = new PDO("pgsql:host=".$this->server_address.";port=".$this->server_port.";dbname=".$this->server_database.";user=comgate_drepa;password=62032492");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }elseif($this->server_type == 'MY_MAIX'){
                $this->conn = new PDO("mysql:host=".$this->server_address.";dbname=".$this->server_database,"it","maxi-trus971/");
                $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            }else{
                die('Není zvolen správný typ serveru');
            }
        }
        catch(Exception $e)
        {
            die( print_r( $e->getMessage() ) );
        }
    }

    public function version(){
        return $this->version;
    }

    public function change_db() {
        try
        {
            if(!$this->conn){
                $this->connect();
            }
        }
        catch(Exception $e)
        {
            die( print_r( $e->getMessage() ) );
        }

        if($this->server_type == 'MS'){
            $this->conn->exec('use ['.($this->server_database).']');
            return 'OK';
        }elseif(substr($this->server_type,0,2) == 'MY'){
            $this->conn->exec('use '.($this->server_database).'');
            return 'OK';
        }else{
            return 'Pro tento typ serveru nelze menit databaze.';
        }

    }

    public function query($q,$fetch_Mode = PDO::FETCH_BOTH){
        try
        {
            if(!$this->conn){
                $this->connect();
            }
            if (!$this->fetchModeCheck($fetch_Mode)) {
                throw new Exception('Bad fetch mode');
            }
                $getRes = $this->conn->prepare($q);
                $getRes->execute();
                if(substr($this->server_type,0,2) == 'MY'){
                    $rawStatement = explode(" ", $q);
                    $statement = strtolower($rawStatement[0]);
                    if ($statement === 'select' || $statement === 'show') {
                        $results = $getRes->fetchAll(PDO::FETCH_BOTH);
                    } else {
                        $results = array();
                    }
                }else{
                    $results = $getRes->fetchAll($fetch_Mode);
                }
                return $results;

        }
        catch(Exception $e)
        {
            print_r( $e->getMessage() ) ;
            return false;
        }
    }

    private function paramCheck($p1,$p2){
        if(count($p1)!=count($p2)){
            return false;
        }

        foreach($p2 as $key => $value){
            if(!in_array($value,$this->support_types)){
                return false;
            }
            if(!isset($p1[$key])){
                return false;
            }
        }
        return true;
    }

    public function fetchModeCheck($fetchMode)
    {
        if (in_array($fetchMode, $this->fetchModes)) {
            return true;
        } else {
            return false;
        }
    }

    private function str_replace_first($from, $to, $content)
    {
        $from = '/'.preg_quote($from, '/').'/';

        return preg_replace($from, $to, $content, 1);
    }

    public function query_bind($q,$param,$param_type, $fetch_Mode = PDO::FETCH_BOTH){
        try
        {
            if(!$this->conn){
                $this->connect();
            }
            if(!$this->paramCheck($param,$param_type)){
                throw new Exception('Bad binds parameters.');
            }
            if (!$this->fetchModeCheck($fetch_Mode)) {
                throw new Exception('Bad fetch mode');
            }

            if(strpos($q,"( ? )") or strpos($q,"(? )") or strpos($q,"( ?)")){
                throw new Exception('Parameters IN must be (?) instead of ( ? ).');
            }

            /* Nastaveni parametru IN */
            foreach($param as $key => $value){
                $inQuery = "";
                $pdoParams = "";
                if(is_array($value)){
                    if(count($value)>1) {
                        //print_r($param);
                        //echo $key;
                        unset($param[$key]);
                        $inQuery = ' (' . implode(',', array_fill(0, count($value), '?')) . ') ';
                        $pdoParams = array_fill(0, count($value), $param_type[$key]);
                        unset($param_type[$key]);
                        $q = $this->str_replace_first('(?)', $inQuery, $q);
                        array_splice($param, $key + 1, 0, $value);
                        array_splice($param_type, $key + 1, 0, $pdoParams);
                    }else{
                        $param[$key] = implode("",$param[$key]);
                        $q = $this->str_replace_first('(?)', '( ? )', $q);
                    }
                }

            }

            $getRes = $this->conn->prepare($q);
            $i=1;
            foreach($param as $key => $value){
                if(trim($param[$key])==''){ $param[$key] = null; }
                $getRes->bindParam($i,$param[$key],$param_type[$key]);
                $i++;
            }
            $getRes->execute();
            if(substr($this->server_type,0,2) == 'MY'){
                $rawStatement = explode(" ", $q);
                $statement = strtolower($rawStatement[0]);
                if ($statement === 'select' || $statement === 'show') {
                    $results = $getRes->fetchAll(PDO::FETCH_BOTH);
                } else {
                    $results = array();
                }
            }else{
                $results = $getRes->fetchAll($fetch_Mode);
            }
            return $results;
        }
        catch(Exception $e)
        {
            print_r( $e->getMessage() ) ;
            return false;
        }
    }

    public function check_table($db,$table,$typ='PG'){
        if(!is_a($db,"db")){
            echo "Bad datasource\n";
            return false;
        }
        if(trim($table)==''){
            echo "Table must be value.\n";
            return false;
        }

        if($typ=='PG'){
            $table = explode(".",$table);
            if(count($table)>1){
                $schemaTable = $table[0];
                $table = $table[1];
            }else{
                $schemaTable = "public";
                $table = $table[0];
            }
            $qOvereni = "
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE  table_schema = ?
                    AND    table_name   = ?
                );
            ";
            $result = $db->query_bind(
                $qOvereni,
                array($schemaTable,$table),
                array(PDO::PARAM_STR,PDO::PARAM_STR)
            );
            return $result;
        }else{
            echo "Supported only PG transfer.";
            return false;
        }
    }

    public function transferTable($db1,$db2,$srcTable,$destTable,$typ="PG"){
        $arr_val = [];
        $arr_name = [];
        if($typ!="PG"){
            die('Supported only Postgres');
        }
        if(!is_a($db1,"db") or !is_a($db2,"db")){
            die('Param1 a 2 must be instance of class "db".');
        }
        if($srcTable==''){
            die('You have to provide source table name.');
        }


        $overExistenciZdroje = db::check_table($db1,$srcTable,$typ);
        if(!$overExistenciZdroje[0]["exists"]){
            die("Table doesnt exist");
        }


        $cil = ($destTable == '') ? $srcTable : $destTable;
        $cil = explode(".",$cil);
        $cil = $cil[count($cil)-1];

        $overExistenciCile = db::check_table($db2,$cil,$typ);
        if($overExistenciCile[0]["exists"]){
            die("Table already exist in destination.");
        }

        $tmpBuffer = $db1->query("select * from $srcTable");
        if(count($tmpBuffer)==0){
            die('Source table doesnt have data');
        }

        foreach($tmpBuffer as $key=>$value){
            $tmpPeace = [];

            foreach($value as $peaceKey => $peace){
                if(!is_int($peaceKey)) {
                    if($peace==null){
                        $tmpPeace[] = 'NULL';
                    }else{
                        $tmpPeace[] = (is_int($peace)) ? $peace . "::int" : "'" . $peace . "'::text";
                    }
                    if($key==0){
                        $arr_name[] = $peaceKey;
                    }
                }
            }

            $arr_val[] = "(".(implode(",",$tmpPeace)).")";
        }

        if(count($arr_val)>100000){
            $arr_val_tmp = array_chunk($arr_val,100000);
            foreach($arr_val_tmp as $k => $val){
                if($k==0){
                    $makeTable = $db2->query("
                                        CREATE TABLE $cil AS                                     
                                        WITH t (".(implode(",",$arr_name)).") AS (
                                        VALUES
                                            ".(implode(",",$val))."
                                        )
                                        SELECT * FROM t;
                    ");
                }else{
                    $updateTable = $db2->query("
                                        INSERT INTO $cil values
                                        ".(implode(",",$val))
                    );
                }
            }
        }else{
            $makeTable = $db2->query("
                CREATE TABLE $cil AS                                     
                WITH t (".(implode(",",$arr_name)).") AS (
                VALUES
                    ".(implode(",",$arr_val))."
                )
                SELECT * FROM t;
            ");

        }
        return $makeTable;

    }


}


