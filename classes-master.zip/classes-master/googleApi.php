<?php
//composer require google/apiclient:^2.0
require __DIR__ . '/../vendor/autoload.php';

class googleApi
{
    private $client;
    private $service;
    private $version = '1.0';

    private $configPath = 'credentials.json';
    private $tokenPath = 'token.json';

    public function __construct (){
        if (php_sapi_name() !== 'cli') {
            throw new Exception('This application must be run on the command line.');
        }

        $this->client = $this->getClient();
        $this->service = $this->service = new Google_Service_Directory($this->client);
    }

    protected function getClient()
    {
        $client = new Google_Client();
        $client->setApplicationName('comdata-czech');
        $client->setScopes(array(Google_Service_Directory::ADMIN_DIRECTORY_USER_READONLY,Google_Service_Directory::ADMIN_DIRECTORY_ORGUNIT_READONLY,Google_Service_Directory::ADMIN_DIRECTORY_USER_ALIAS_READONLY));
        $client->setAuthConfig($this->configPath);
        $client->setApprovalPrompt('auto');
        $tokenPath = $this->tokenPath;
        if (file_exists($tokenPath)) {
            $accessToken = json_decode(file_get_contents($tokenPath), true);
            $client->setAccessToken($accessToken);
        }


        if ($client->isAccessTokenExpired()) {
            if ($client->getRefreshToken()) {
                $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
            } else {
                $authUrl = $client->createAuthUrl();
                printf("Open the following link in your browser:\n%s\n", $authUrl);
                print 'Enter verification code: ';
                $authCode = trim(fgets(STDIN));

                $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
                $client->setAccessToken($accessToken);

                if (array_key_exists('error', $accessToken)) {
                    throw new Exception(join(', ', $accessToken));
                }
            }
            if (!file_exists(dirname($tokenPath))) {
                if (!mkdir($concurrentDirectory = dirname($tokenPath), 0700, true) && !is_dir($concurrentDirectory)) {
                    throw new \RuntimeException(sprintf('Directory "%s" was not created', $concurrentDirectory));
                }
            }
            file_put_contents($tokenPath, json_encode($client->getAccessToken()));
        }
        return $client;
    }

    /**
     * Vytáhné veškeré orgUnits na základě orgUnitPath - default: /Comdata Italy/Comdata Czech
     * @param string $customerID
     * @param array $optParams
     * @return Google_Service_Directory_OrgUnits
     */
    public function getAllOrgUnits($customerID = 'my_customer', $optParams = array()): Google_Service_Directory_OrgUnits
    {
        if(count($optParams) === 0){
            $optParams = array(
                'orgUnitPath' => '/Comdata Italy/Comdata Czech',
                'type' => 'all'
            );
        }
        return $this->service->orgunits->listOrgunits('my_customer', $optParams);
    }

}